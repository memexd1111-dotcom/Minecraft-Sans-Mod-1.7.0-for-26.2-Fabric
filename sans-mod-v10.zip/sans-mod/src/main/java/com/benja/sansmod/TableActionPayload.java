package com.benja.sansmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Cliente -> servidor: inscribir (insert = true) o quitar una habilidad del amuleto en la Mesa de Sans. */
public record TableActionPayload(boolean insert, int ability) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<TableActionPayload> TYPE =
            new CustomPacketPayload.Type<>(SansMod.id("table_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TableActionPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, TableActionPayload::insert,
            ByteBufCodecs.VAR_INT, TableActionPayload::ability,
            TableActionPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
