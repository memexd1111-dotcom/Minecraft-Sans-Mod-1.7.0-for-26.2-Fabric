package com.benja.sansmod;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Toda la lógica de las habilidades (solo servidor).
 * Para no necesitar renderers propios, los objetos visibles (huesos, calaveras, muro) son
 * armor stands invisibles con un objeto en la cabeza, y los rayos son partículas.
 */
public final class AbilityLogic {
    /** Altura de la cabeza de un armor stand respecto a sus pies (para centrar el objeto). */
    private static final double HEAD_OFFSET = 1.75;
    /** Evita recursión cuando "Mal momento" re-aplica el daño aumentado. */
    private static boolean boosting = false;

    private AbilityLogic() {}

    record Hit(Vec3 end, LivingEntity entity) {}

    // =====================================================================
    //  Utilidades
    // =====================================================================

    static void msg(ServerPlayer player, Component text) {
        player.sendSystemMessage(text, true);
    }

    static void sound(ServerLevel level, Vec3 pos, SoundEvent event, float volume, float pitch) {
        level.playSound(null, pos.x, pos.y, pos.z, event, SoundSource.PLAYERS, volume, pitch);
    }

    static void particles(ServerLevel level, net.minecraft.core.particles.ParticleOptions type,
                                  Vec3 pos, int count, double spread, double speed) {
        int c = count;
        double q = SansConfig.particleScale;
        if (count > 0 && q < 1.0) { // calidad baja/media: menos partículas (con redondeo al azar para no perder las sueltas)
            double exact = count * q;
            c = (int) exact;
            if (java.util.concurrent.ThreadLocalRandom.current().nextDouble() < exact - c) c++;
            if (c <= 0) return;
        }
        level.sendParticles(type, pos.x, pos.y, pos.z, c, spread, spread, spread, speed);
    }

    private static double damageMul(PlayerState st, long now) {
        return st.seriousUntil > now ? SansConfig.d("eye.damage_multiplier") : 1.0;
    }

    /** Objetivo válido: vivo y que no sea una mascota, un aldeano o alguien de tu equipo (según la config). */
    private static boolean valid(Entity self, LivingEntity e) {
        if (e == self || !e.isAlive() || e.isSpectator() || e.getType() == EntityTypes.ARMOR_STAND) return false;
        if (SansConfig.b("protect.pets") && e instanceof TamableAnimal pet && pet.isTame()) return false;
        if (SansConfig.b("protect.villagers")
                && (e.getType() == EntityTypes.VILLAGER || e.getType() == EntityTypes.WANDERING_TRADER)) {
            return false;
        }
        if (SansConfig.b("protect.teams") && self instanceof ServerPlayer && e.isAlliedTo(self)) return false;
        return true;
    }

    static Hit trace(ServerLevel level, Entity owner, Vec3 from, Vec3 dir, double range) {
        Vec3 to = from.add(dir.scale(range));
        BlockHitResult block = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
        Vec3 end = block.getType() == HitResult.Type.MISS ? to : block.getLocation();

        AABB box = new AABB(from, end).inflate(1.0);
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        Vec3 bestPos = end;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> valid(owner, x))) {
            Optional<Vec3> r = e.getBoundingBox().inflate(0.3).clip(from, end);
            if (r.isPresent()) {
                double d = from.distanceToSqr(r.get());
                if (d < bestDist) {
                    bestDist = d;
                    best = e;
                    bestPos = r.get();
                }
            }
        }
        return new Hit(best != null ? bestPos : end, best);
    }

    /** Daño que ignora la invulnerabilidad corta (para que varios golpes seguidos cuenten). */
    static void hurtPlain(ServerLevel level, ServerPlayer owner, LivingEntity target, float amount) {
        target.invulnerableTime = 0;
        target.hurtServer(level, level.damageSources().playerAttack(owner), amount);
    }

    static void hurt(ServerLevel level, ServerPlayer owner, LivingEntity target, float base, PlayerState st) {
        long now = level.getServer().getTickCount();
        hurtPlain(level, owner, target, (float) (base * damageMul(st, now)));
        if (st.karmaOn && target.isAlive()) {
            Karma.apply(owner, target, now); // KR: daño que se acumula con el tiempo
        }
    }

    /** Sacudida de cámara para los jugadores cercanos (más fuerte cuanto más cerca). */
    static void shake(ServerLevel level, Vec3 pos, double radius, float intensity, int ticks) {
        for (ServerPlayer sp : level.getServer().getPlayerList().getPlayers()) {
            if (sp.level() != level) continue;
            double d = sp.position().distanceTo(pos);
            if (d > radius) continue;
            float k = (float) (1.0 - d / radius);
            ServerPlayNetworking.send(sp, new ShakePayload(intensity * (0.35f + 0.65f * k), ticks));
        }
    }

    // ----- inclinar la cabeza de un armor stand (setHeadPose se llama por reflexión: si no existe, se ignora) -----
    private static Constructor<?> rotCtor;
    private static Method headPoseMethod;
    private static boolean tiltBroken = false;

    static void tiltStand(LivingEntity stand, float pitchDeg) {
        if (stand == null || !stand.isAlive() || tiltBroken) return;
        try {
            if (rotCtor == null) {
                Class<?> rot = Class.forName("net.minecraft.core.Rotations");
                rotCtor = rot.getConstructor(float.class, float.class, float.class);
                headPoseMethod = stand.getClass().getMethod("setHeadPose", rot);
            }
            headPoseMethod.invoke(stand, rotCtor.newInstance(pitchDeg, 0.0f, 0.0f));
        } catch (ReflectiveOperationException | RuntimeException e) {
            tiltBroken = true;
            System.err.println("[sansmod] No se pudo inclinar la calavera (setHeadPose): " + e);
        }
    }

    /** Ángulo de cabeceo (grados, positivo = mirar hacia abajo) de una dirección. */
    static float pitchOf(Vec3 dir) {
        return (float) -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, dir.y))));
    }

    static LivingEntity makeStand(ServerLevel level, Vec3 headPos, float yaw, ItemStack head) {
        LivingEntity stand = EntityTypes.ARMOR_STAND.create(level, EntitySpawnReason.TRIGGERED);
        if (stand == null) return null;
        stand.setPos(headPos.x, headPos.y - HEAD_OFFSET, headPos.z);
        stand.setInvisible(true);
        stand.setNoGravity(true);
        stand.setInvulnerable(true);
        stand.setSilent(true);
        stand.setYRot(yaw);
        stand.setYBodyRot(yaw);
        stand.setYHeadRot(yaw);
        stand.setItemSlot(EquipmentSlot.HEAD, head);
        level.addFreshEntity(stand);
        return stand;
    }

    static void moveStand(LivingEntity stand, Vec3 headPos) {
        if (stand != null && stand.isAlive()) {
            stand.setPos(headPos.x, headPos.y - HEAD_OFFSET, headPos.z);
        }
    }

    /** Mueve un armor stand y lo gira hacia {@code yaw} (para que la calavera siga tu mirada). */
    private static void aimStand(LivingEntity stand, Vec3 headPos, float yaw) {
        moveStand(stand, headPos);
        if (stand != null && stand.isAlive()) {
            stand.setYRot(yaw);
            stand.setYBodyRot(yaw);
            stand.setYHeadRot(yaw);
        }
    }

    private static float yawOf(Vec3 dir) {
        return (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
    }

    /** Pone en enfriamiento una habilidad (lo usa la telequinesis al soltar al objetivo). */
    static void startCooldown(ServerPlayer p, PlayerState st, Ability a, long now) {
        int cd = a.cooldownTicks();
        st.cooldownEnd[a.ordinal()] = now + cd;
        st.cooldownTotal[a.ordinal()] = cd;
        sendSync(p, st, now);
    }

    /**
     * Desplazamiento más largo (hasta {@code offset}) que la caja de la entidad puede recorrer sin
     * atravesar bloques. Avanza a pasos pequeños, así que no se cuela por muros finos; si choca con
     * el suelo o el techo, sigue deslizándose en horizontal en vez de entrar en el bloque.
     */
    static Vec3 sweep(ServerLevel level, Entity e, Vec3 offset) {
        double len = offset.length();
        if (len < 1.0E-4) return Vec3.ZERO;
        Vec3 dir = offset.scale(1.0 / len);
        AABB box = e.getBoundingBox();
        Vec3 best = Vec3.ZERO;
        for (double d = 0.2; d <= len + 1.0E-6; d += 0.2) {
            Vec3 full = dir.scale(d);
            if (level.noCollision(e, box.move(full))) {
                best = full;
                continue;
            }
            Vec3 slide = new Vec3(full.x, best.y, full.z);
            if ((Math.abs(dir.x) > 1.0E-3 || Math.abs(dir.z) > 1.0E-3) && level.noCollision(e, box.move(slide))) {
                best = slide;
                continue;
            }
            break;
        }
        return best;
    }

    // =====================================================================
    //  Lanzar habilidad (llega desde el cliente)
    // =====================================================================

    public static void cast(ServerPlayer player, int index, int chargeTicks) {
        if (index < 0 || index >= Ability.ALL.length) return;
        if (!player.isAlive() || player.isSpectator()) return;

        Ability ability = Ability.ALL[index];
        ServerLevel level = (ServerLevel) player.level();
        MinecraftServer server = level.getServer();
        long now = server.getTickCount();

        PlayerState st = PlayerState.of(player);
        if (SansConfig.b("require_item") && !SansMod.hasCharm(player)) {
            msg(player, Component.translatable("msg.sansmod.need_charm"));
            return;
        }
        if (!st.isUnlocked(ability)) {
            msg(player, Component.translatable("msg.sansmod.need_unlock"));
            return;
        }
        int charge = ability.charges
                ? Math.max(0, Math.min(chargeTicks, Math.max(1, SansConfig.i("charge.max_ticks")))) : 0;
        if (ability == Ability.TELEKINESIS && Telekinesis.isHolding(player)) {
            Telekinesis.release(player, level, st, now); // segundo uso: lanzar
            return;
        }
        if (now < st.cooldownEnd[index]) {
            double secs = (st.cooldownEnd[index] - now) / 20.0;
            msg(player, Component.translatable("msg.sansmod.cooldown", String.format("%.1f", secs)));
            return;
        }
        boolean manaMode = SansConfig.s("resource_mode").equalsIgnoreCase("mana");
        double cost = (manaMode && !ability.toggle) ? SansConfig.d("mana.cost." + ability.id) : 0.0;
        if (cost > 0 && st.mana < cost) {
            msg(player, Component.translatable("msg.sansmod.need_mana", String.format("%.0f", cost)));
            return;
        }

        boolean ok = switch (ability) {
            case DODGE -> toggleDodge(player, st);
            case KARMA -> toggleKarma(player, st);
            case BONE -> bone(player, level, st, charge, BoneKind.NORMAL);
            case BLUE_BONE -> bone(player, level, st, charge, BoneKind.BLUE);
            case ORANGE_BONE -> bone(player, level, st, charge, BoneKind.ORANGE);
            case BONE_WALL -> boneWall(player, level, st);
            case BLASTER -> blaster(player, level, st, charge);
            case BLASTER_RAIN -> blasterRain(player, level, st);
            case TELEKINESIS -> Telekinesis.start(player, level, st, now);
            case TELEPORT -> teleport(player, level);
            case EYE -> eye(player, level, st, now);
            case BAD_TIME -> badTime(player, level, st, now);
        };

        if (ok) {
            st.mana = Math.max(0.0, st.mana - cost);
            if (ability != Ability.TELEKINESIS) { // la telequinesis empieza su enfriamiento al soltar
                int cd = (int) Math.round(ability.cooldownTicks() * Progression.cooldownMul(st, ability));
                st.cooldownEnd[index] = now + cd;
                st.cooldownTotal[index] = cd;
            }
            if (!ability.toggle && !manaMode) {
                player.causeFoodExhaustion((float) SansConfig.d("exhaustion_per_cast"));
            }
            if (!ability.toggle) Progression.award(player, level, st, ability);
            sendSync(player, st, now);
            st.save(player, now);
        }
    }

    /** Guarda el estado de todos los jugadores conectados (al cerrar el mundo). */
    public static void saveAll(MinecraftServer server) {
        long now = server.getTickCount();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PlayerState.of(p).save(p, now);
        }
    }

    // ---------- interruptores ----------

    private static boolean toggleDodge(ServerPlayer p, PlayerState st) {
        st.dodgeOn = !st.dodgeOn;
        msg(p, Component.translatable(st.dodgeOn ? "msg.sansmod.dodge_on" : "msg.sansmod.dodge_off"));
        return true;
    }

    private static boolean toggleKarma(ServerPlayer p, PlayerState st) {
        st.karmaOn = !st.karmaOn;
        msg(p, Component.translatable(st.karmaOn ? "msg.sansmod.karma_on" : "msg.sansmod.karma_off"));
        return true;
    }

    // ---------- huesos ----------

    private enum BoneKind { NORMAL, BLUE, ORANGE }

    /** Nivel de carga (0 a 3) según los ticks que se mantuvo la tecla. */
    private static int chargeLevel(int charge) {
        int per = Math.max(1, SansConfig.i("charge.max_ticks") / 4);
        return Math.min(3, charge / per);
    }

    /**
     * Huesos en abanico. Con carga salen más huesos. El hueso azul solo daña a quien se mueve y el
     * naranja solo a quien está quieto (como en Undertale).
     */
    private static boolean bone(ServerPlayer p, ServerLevel level, PlayerState st, int charge, BoneKind kind) {
        MinecraftServer server = level.getServer();
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        int lvl = chargeLevel(charge);
        int count = Math.max(1, SansConfig.i("bone.count")) + lvl * Math.max(0, SansConfig.i("bone.charge_extra"));
        double spread = Math.toRadians(SansConfig.d("bone.spread_degrees"));
        double speed = Math.max(0.5, SansConfig.d("bone.speed"));
        double range = SansConfig.d("bone.range");
        net.minecraft.world.item.Item model = kind == BoneKind.BLUE ? ModItems.BLUE_BONE_PROJECTILE
                : kind == BoneKind.ORANGE ? ModItems.ORANGE_BONE_PROJECTILE : ModItems.BONE_PROJECTILE;
        Ability self = kind == BoneKind.BLUE ? Ability.BLUE_BONE : kind == BoneKind.ORANGE ? Ability.ORANGE_BONE : Ability.BONE;
        double baseDamage = Progression.dmg(st, self, kind == BoneKind.BLUE ? SansConfig.d("blue_bone.damage")
                : kind == BoneKind.ORANGE ? SansConfig.d("orange_bone.damage") : SansConfig.d("bone.damage"));
        float damage = (float) (baseDamage * (1.0 + 0.1 * lvl));

        for (int k = 0; k < count; k++) {
            double angle = (k - (count - 1) / 2.0) * spread;
            Vec3 dir = look.yRot((float) angle).normalize();
            Hit hit = trace(level, p, eye, dir, range);
            Vec3 start = eye.add(dir.scale(0.9));
            double dist = Math.max(1.0, eye.distanceTo(hit.end()));
            int ticks = Math.max(1, (int) Math.ceil(dist / speed));

            LivingEntity stand = makeStand(level, start, yawOf(dir), new ItemStack(model));
            for (int t = 1; t <= ticks; t++) {
                final int tt = t;
                Scheduler.later(server, t, () -> {
                    Vec3 pos = start.add(dir.scale(speed * tt));
                    moveStand(stand, pos);
                    if (kind == BoneKind.BLUE) {
                        particles(level, ParticleTypes.SOUL_FIRE_FLAME, pos, 1, 0.06, 0.0);
                    } else if (kind == BoneKind.ORANGE) {
                        particles(level, ParticleTypes.FLAME, pos, 1, 0.06, 0.0);
                    }
                });
            }
            Scheduler.later(server, ticks + 1, () -> {
                if (stand != null) stand.discard();
            });

            LivingEntity target = hit.entity();
            if (target == null) continue;
            if (kind == BoneKind.NORMAL) {
                Scheduler.later(server, ticks, () -> {
                    if (target.isAlive()) hurt(level, p, target, damage, st);
                });
            } else {
                // se mide cuánto se movió el objetivo en los últimos ticks antes del impacto
                final Vec3[] before = new Vec3[1];
                Scheduler.later(server, Math.max(0, ticks - 4), () -> {
                    if (target.isAlive()) before[0] = target.position();
                });
                Scheduler.later(server, ticks, () -> {
                    if (!target.isAlive()) return;
                    boolean moving = before[0] != null && target.position().distanceToSqr(before[0]) > 0.0225;
                    boolean hits = kind == BoneKind.BLUE ? moving : !moving;
                    Vec3 at = target.position().add(0, target.getBbHeight() / 2.0, 0);
                    if (hits) {
                        hurt(level, p, target, damage, st);
                        particles(level, kind == BoneKind.BLUE ? ParticleTypes.SOUL_FIRE_FLAME : ParticleTypes.FLAME,
                                at, 12, 0.35, 0.05);
                    } else {
                        particles(level, ParticleTypes.POOF, at, 6, 0.25, 0.02); // el hueso lo atraviesa
                    }
                });
            }
        }
        sound(level, eye, SoundEvents.SKELETON_SHOOT, 1.0f, 1.3f - 0.1f * lvl);
        return true;
    }

    private static boolean boneWall(ServerPlayer p, ServerLevel level, PlayerState st) {
        MinecraftServer server = level.getServer();
        Vec3 look = p.getLookAngle();
        Vec3 fwd = new Vec3(look.x, 0, look.z);
        fwd = fwd.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : fwd.normalize();
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);

        double distance = SansConfig.d("bone_wall.distance");
        int width = Math.max(1, SansConfig.i("bone_wall.width"));
        int rise = Math.max(2, SansConfig.i("bone_wall.rise_ticks"));
        Vec3 base = p.position().add(fwd.scale(distance));
        double floorY = p.getY();
        float yaw = yawOf(fwd);

        List<LivingEntity> stands = new ArrayList<>();
        for (int i = 0; i < width; i++) {
            double off = (i - (width - 1) / 2.0);
            Vec3 headPos = new Vec3(base.x + right.x * off, floorY - 0.2, base.z + right.z * off);
            LivingEntity s = makeStand(level, headPos, yaw, new ItemStack(ModItems.BONE_WALL));
            if (s != null) stands.add(s);
        }
        // sube desde el suelo
        double step = 2.0 / rise;
        for (int t = 1; t <= rise; t++) {
            Scheduler.later(server, t, () -> {
                for (LivingEntity s : stands) {
                    if (s.isAlive()) s.setPos(s.getX(), s.getY() + step, s.getZ());
                }
            });
        }
        sound(level, base, SoundEvents.BONE_BLOCK_BREAK, 1.5f, 0.7f);

        // golpe cuando termina de subir
        final Vec3 fFwd = fwd;
        Scheduler.later(server, rise, () -> {
            double half = width / 2.0 + 0.5;
            double[] xs = {base.x + right.x * half + fFwd.x * 0.9, base.x - right.x * half + fFwd.x * 0.9,
                    base.x + right.x * half - fFwd.x * 0.9, base.x - right.x * half - fFwd.x * 0.9};
            double[] zs = {base.z + right.z * half + fFwd.z * 0.9, base.z - right.z * half + fFwd.z * 0.9,
                    base.z + right.z * half - fFwd.z * 0.9, base.z - right.z * half - fFwd.z * 0.9};
            double minX = Math.min(Math.min(xs[0], xs[1]), Math.min(xs[2], xs[3]));
            double maxX = Math.max(Math.max(xs[0], xs[1]), Math.max(xs[2], xs[3]));
            double minZ = Math.min(Math.min(zs[0], zs[1]), Math.min(zs[2], zs[3]));
            double maxZ = Math.max(Math.max(zs[0], zs[1]), Math.max(zs[2], zs[3]));
            AABB box = new AABB(minX, floorY - 0.5, minZ, maxX, floorY + 3.0, maxZ);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
                hurt(level, p, e, (float) Progression.dmg(st, Ability.BONE_WALL, SansConfig.d("bone_wall.damage")), st);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.7, 0));
                e.hurtMarked = true;
            }
        });
        Scheduler.later(server, rise + 25, () -> {
            for (LivingEntity s : stands) s.discard();
        });
        return true;
    }

    // ---------- blasters ----------

    /** Distancia del centro de la calavera a su boca (el modelo mide ~1 bloque hacia delante). */
    private static final double MOUTH = 1.0;

    /**
     * Calavera que carga y dispara. La carga que mantuviste con la tecla hace el rayo más grueso y
     * dañino y acorta la espera. La calavera se inclina hacia donde miras y abre la mandíbula.
     */
    private static boolean blaster(ServerPlayer p, ServerLevel level, PlayerState st, int charge) {
        MinecraftServer server = level.getServer();
        double frac = Math.min(1.0, charge / (double) Math.max(1, SansConfig.i("charge.max_ticks")));
        Vec3 look = p.getLookAngle();
        Vec3 skullPos = p.getEyePosition().add(look.scale(2.2));
        LivingEntity skull = makeStand(level, skullPos, yawOf(look), new ItemStack(ModItems.BLASTER_SKULL));
        tiltStand(skull, pitchOf(look));

        int chargeTicks = Math.max(8, (int) Math.round(Math.max(2, SansConfig.i("blaster.charge_ticks")) * (1.0 - 0.5 * frac)));
        float damage = (float) (Progression.dmg(st, Ability.BLASTER, SansConfig.d("blaster.damage")) * (1.0 + SansConfig.d("blaster.charge_damage_bonus") * frac));
        double radius = SansConfig.d("blaster.beam_radius") * (1.0 + SansConfig.d("blaster.charge_radius_bonus") * frac);
        int halfAt = (int) (chargeTicks * 0.55);
        int openAt = (int) (chargeTicks * 0.85);

        sound(level, skullPos, SoundEvents.BEACON_ACTIVATE, 1.2f, 1.5f);
        for (int t = 1; t < chargeTicks; t++) {
            final int tt = t;
            Scheduler.later(server, t, () -> {
                if (skull == null || !skull.isAlive() || p.isRemoved()) return;
                Vec3 l = p.getLookAngle();
                Vec3 pos = p.getEyePosition().add(l.scale(2.2));
                aimStand(skull, pos, yawOf(l));
                tiltStand(skull, pitchOf(l));
                if (tt == halfAt) skull.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.BLASTER_SKULL_HALF));
                if (tt == openAt) skull.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.BLASTER_SKULL_OPEN));
                Vec3 mouthPos = pos.add(l.scale(MOUTH));
                // esfera de energía que crece y un tono que sube hasta el disparo
                particles(level, ParticleTypes.END_ROD, mouthPos, 1 + (tt * 5) / chargeTicks, 0.12, 0.0);
                if (tt % 2 == 0) {
                    particles(level, ParticleTypes.ELECTRIC_SPARK, mouthPos, 4, 0.3, 0.05);
                }
                if (tt % 4 == 0) {
                    sound(level, mouthPos, SoundEvents.AMETHYST_BLOCK_CHIME, 0.7f, 0.7f + 1.3f * tt / chargeTicks);
                }
            });
        }
        Scheduler.later(server, chargeTicks, () -> {
            Vec3 dir = p.isRemoved() ? look : p.getLookAngle();
            Vec3 center = (skull != null && skull.isAlive())
                    ? skull.position().add(0, HEAD_OFFSET, 0) : skullPos;
            if (skull != null && skull.isAlive()) skull.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.BLASTER_SKULL_OPEN));
            Vec3 mouth = center.add(dir.scale(MOUTH));
            fireBeam(level, p, mouth, dir, SansConfig.d("blaster.range"), damage, radius, st);
            shake(level, mouth, 28.0, (float) (1.2 + 1.6 * frac), 10);
        });
        Scheduler.later(server, chargeTicks + 12, () -> {
            if (skull != null) skull.discard();
        });
        return true;
    }

    /**
     * Lluvia de blasters: cada calavera apunta a un punto distinto alrededor del objetivo, un aviso en
     * el suelo se encoge antes de cada rayo y al final cae un pilar de energía sobre el objetivo.
     */
    private static boolean blasterRain(ServerPlayer p, ServerLevel level, PlayerState st) {
        MinecraftServer server = level.getServer();
        Hit hit = trace(level, p, p.getEyePosition(), p.getLookAngle(), SansConfig.d("blaster_rain.range"));
        Vec3 target = hit.entity() != null
                ? hit.entity().position().add(0, hit.entity().getBbHeight() / 2.0, 0)
                : hit.end();
        double groundY = (hit.entity() != null ? hit.entity().getY() : target.y) + 0.05;

        int count = Math.max(1, SansConfig.i("blaster_rain.count"));
        double radius = SansConfig.d("blaster_rain.radius");
        double spread = SansConfig.d("blaster_rain.spread");
        int warn = Math.max(4, SansConfig.i("blaster_rain.warning_ticks"));
        float dmg = (float) Progression.dmg(st, Ability.BLASTER_RAIN, SansConfig.d("blaster_rain.damage"));

        int lastShot = 0;
        List<LivingEntity> skulls = new ArrayList<>();
        for (int k = 0; k < count; k++) {
            double angle = k * 2.0 * Math.PI / count;
            Vec3 skullPos = new Vec3(target.x + Math.cos(angle) * radius,
                    target.y + 3.0 + (k % 2) * 0.8, target.z + Math.sin(angle) * radius);

            // el primer rayo cae justo sobre el objetivo; los demás en puntos repartidos a su alrededor
            Vec3 impact = target;
            if (k > 0) {
                double a2 = p.getRandom().nextDouble() * 2.0 * Math.PI;
                double d2 = spread * Math.sqrt(p.getRandom().nextDouble());
                impact = new Vec3(target.x + Math.cos(a2) * d2, target.y, target.z + Math.sin(a2) * d2);
            }
            final Vec3 fImpact = impact;
            Vec3 dir = impact.subtract(skullPos).normalize();
            LivingEntity skull = makeStand(level, skullPos, yawOf(dir), new ItemStack(ModItems.BLASTER_SKULL));
            tiltStand(skull, pitchOf(dir));
            if (skull != null) skulls.add(skull);

            int delay = warn + k * 4;
            lastShot = delay;
            Scheduler.later(server, 0, () -> sound(level, skullPos, SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.6f));

            // aviso: un círculo en el suelo que se encoge hasta que cae el rayo
            for (int w = 0; w < delay; w += 3) {
                final double frac = w / (double) delay;
                Scheduler.later(server, w, () -> {
                    double r = 0.35 + 1.4 * (1.0 - frac);
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4.0;
                        Vec3 ring = new Vec3(fImpact.x + Math.cos(a) * r, groundY, fImpact.z + Math.sin(a) * r);
                        particles(level, ParticleTypes.SOUL_FIRE_FLAME, ring, 1, 0.02, 0.0);
                    }
                    particles(level, ParticleTypes.ELECTRIC_SPARK, new Vec3(fImpact.x, groundY, fImpact.z), 1, 0.15, 0.0);
                });
            }

            Vec3 mouth = skullPos.add(dir.scale(MOUTH));
            Scheduler.later(server, Math.max(1, delay - 4), () -> {
                if (skull != null && skull.isAlive()) skull.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.BLASTER_SKULL_OPEN));
            });
            Scheduler.later(server, delay, () -> {
                fireBeam(level, p, mouth, dir, mouth.distanceTo(fImpact) + 2.5, dmg, 1.3, st);
                shake(level, fImpact, 20.0, 0.8f, 6);
            });
        }

        // pilar final sobre el objetivo
        final int finisherAt = lastShot + 10;
        final Vec3 center = new Vec3(target.x, groundY, target.z);
        Scheduler.later(server, finisherAt, () -> {
            AABB box = new AABB(center.x - 3.2, groundY - 1.0, center.z - 3.2, center.x + 3.2, groundY + 6.0, center.z + 3.2);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
                hurt(level, p, e, (float) Progression.dmg(st, Ability.BLASTER_RAIN, SansConfig.d("blaster_rain.finisher_damage")), st);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.5, 0));
                e.hurtMarked = true;
            }
            for (double y = 0; y <= 8.0; y += 0.8) {
                particles(level, ParticleTypes.END_ROD, center.add(0, y, 0), 4, 0.35, 0.02);
                particles(level, ParticleTypes.SOUL_FIRE_FLAME, center.add(0, y, 0), 3, 0.7, 0.0);
            }
            particles(level, ParticleTypes.EXPLOSION, center.add(0, 0.5, 0), 1, 0.0, 0.0);
            particles(level, ParticleTypes.SONIC_BOOM, center.add(0, 1.0, 0), 1, 0.0, 0.0);
            sound(level, center, SoundEvents.WARDEN_SONIC_BOOM, 1.5f, 0.8f);
            shake(level, center, 30.0, 2.0f, 14);
        });
        Scheduler.later(server, finisherAt + 6, () -> {
            for (LivingEntity sk : skulls) sk.discard();
        });
        return true;
    }

    private static void fireBeam(ServerLevel level, ServerPlayer owner, Vec3 from, Vec3 dir,
                                 double range, float damage, double radius, PlayerState st) {
        Vec3 to = from.add(dir.scale(range));
        BlockHitResult block = level.clip(new ClipContext(from, to,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, owner));
        Vec3 end = block.getType() == HitResult.Type.MISS ? to : block.getLocation();
        double len = from.distanceTo(end);

        AABB box = new AABB(from, end).inflate(radius + 0.5);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> valid(owner, x))) {
            if (e.getBoundingBox().inflate(radius).clip(from, end).isPresent()) {
                hurt(level, owner, e, damage, st);
            }
        }

        sound(level, from, SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 1.3f);
        sound(level, from, SoundEvents.BEACON_DEACTIVATE, 1.2f, 1.8f);
        MinecraftServer server = level.getServer();

        // destello en la boca
        particles(level, ParticleTypes.SONIC_BOOM, from, 1, 0.0, 0.0);
        particles(level, ParticleTypes.END_ROD, from, 24, 0.45, 0.15);

        // el rayo en capas (núcleo blanco, cuerpo azul, chispas) y se va afinando hasta desaparecer
        final double thick = Math.max(0.4, radius);
        final double[] fade = {1.0, 0.8, 0.55, 0.3};
        for (int rep = 0; rep < fade.length; rep++) {
            final double f = fade[rep];
            final boolean sparks = rep % 2 == 0;
            Scheduler.later(server, rep * 2, () -> {
                for (double d = 0; d <= len; d += 0.7) {
                    Vec3 at = from.add(dir.scale(d));
                    particles(level, ParticleTypes.END_ROD, at, 2, 0.07 * f, 0.0);
                    particles(level, ParticleTypes.SOUL_FIRE_FLAME, at, 3, thick * 0.45 * f, 0.0);
                    if (sparks) {
                        particles(level, ParticleTypes.ELECTRIC_SPARK, at, 1, thick * 0.8 * f, 0.0);
                    }
                }
            });
        }

        // impacto: explosión y onda expansiva
        particles(level, ParticleTypes.EXPLOSION, end, 1, 0.0, 0.0);
        particles(level, ParticleTypes.SONIC_BOOM, end, 1, 0.0, 0.0);
        particles(level, ParticleTypes.END_ROD, end, 30, 0.6, 0.2);
        particles(level, ParticleTypes.ELECTRIC_SPARK, end, 20, 0.5, 0.25);
        particles(level, ParticleTypes.POOF, end, 12, 0.4, 0.05);
    }

    // ---------- teletransporte ----------

    private static boolean teleport(ServerPlayer p, ServerLevel level) {
        Vec3 look = p.getLookAngle();
        double max = SansConfig.d("teleport.distance");
        Vec3 origin = p.position();
        Vec3 moved = sweep(level, p, look.scale(max)); // se detiene ante muros, techo y suelo
        if (moved.length() < 1.0) {
            msg(p, Component.translatable("msg.sansmod.no_space"));
            return false;
        }
        Vec3 dest = origin.add(moved);
        // rastro cian entre la salida y la llegada, y un eco donde estabas
        int steps = (int) Math.min(40, moved.length() / 0.5);
        for (int i = 1; i < steps; i++) {
            Vec3 at = origin.add(moved.scale(i / (double) steps)).add(0, 1.0, 0);
            particles(level, ParticleTypes.SOUL_FIRE_FLAME, at, 2, 0.12, 0.0);
            if (i % 2 == 0) particles(level, ParticleTypes.END_ROD, at, 1, 0.05, 0.0);
        }
        MinecraftServer srv = level.getServer();
        for (int k = 0; k < 4; k++) {
            Scheduler.later(srv, k * 3, () -> dodgeAura(level, origin));
        }
        particles(level, ParticleTypes.PORTAL, origin.add(0, 1, 0), 30, 0.4, 0.3);
        p.connection.teleport(dest.x, dest.y, dest.z, p.getYRot(), p.getXRot());
        particles(level, ParticleTypes.PORTAL, dest.add(0, 1, 0), 30, 0.4, 0.3);
        sound(level, dest, SoundEvents.ENDERMAN_TELEPORT, 1.0f, 1.2f);
        return true;
    }

    // ---------- ojo brillante ----------

    private static boolean eye(ServerPlayer p, ServerLevel level, PlayerState st, long now) {
        int ticks = (int) (SansConfig.d("eye.duration_seconds") * 20);
        st.seriousUntil = now + ticks;
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, ticks, 0, false, false));
        sound(level, p.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1.5f, 0.5f);
        msg(p, Component.translatable("msg.sansmod.eye"));
        return true;
    }

    // ---------- mal momento ----------

    private static boolean badTime(ServerPlayer p, ServerLevel level, PlayerState st, long now) {
        st.badTimeUntil = now + (long) (SansConfig.d("bad_time.duration_seconds") * 20);
        sound(level, p.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 1.0f, 0.8f);
        msg(p, Component.translatable("msg.sansmod.bad_time"));
        return true;
    }

    // =====================================================================
    //  Tick del servidor: tareas, recuperación, efectos continuos, sincronización
    // =====================================================================

    public static void serverTick(MinecraftServer server) {
        Scheduler.tick(server);
        long now = server.getTickCount();
        Telekinesis.tick(server, now);
        Karma.tick(server, now);
        SansMobs.tick(server, now);
        long recovery = Math.max(1, (long) (SansConfig.d("dodge.recovery_seconds") * 20));

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            PlayerState st = PlayerState.of(p);
            ServerLevel level = (ServerLevel) p.level();

            int maxMana = Progression.maxMana(st);
            if (st.mana < 0) st.mana = maxMana;
            if (st.mana < maxMana) st.mana = Math.min(maxMana, st.mana + Progression.manaRegen(st));
            if (st.fatigue > 0 && now - st.lastRecoverTick >= recovery) {
                st.fatigue--;
                st.lastRecoverTick = now;
            }
            if (st.seriousUntil > now) {
                eyeParticles(p, level, now);
            }
            if (now - st.lastDodgeTick <= SansConfig.i("dodge.window_ticks") && now % 2 == 0) {
                dodgeAura(level, p.position()); // aura mientras dura el esquive
            }
            if (now % 40 == 0) {
                st.save(p, now);
            }
            if (st.karmaOn && now % 3 == 0) {
                karmaAura(p, level, now);
            }
            if (st.badTimeUntil > now && now % 5 == 0) {
                badTimeAura(p, level);
            }
            if (now % 4 == 0 && SansMod.hasCharm(p)) {
                sendSync(p, st, now);
            }
        }
    }

    /**
     * Ojo izquierdo en llamas: núcleo blanco muy brillante, llama azul que sube y chispas, cada tick,
     * para que resalte con fuerza contra el resto del jugador.
     */
    private static void eyeParticles(ServerPlayer p, ServerLevel level, long now) {
        Vec3 look = p.getLookAngle();
        Vec3 right = new Vec3(-look.z, 0, look.x);
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 pos = p.getEyePosition().add(look.scale(0.45)).subtract(right.scale(0.14)).add(0, 0.03, 0);

        // núcleo blanco-azulado, muy brillante
        particles(level, ParticleTypes.END_ROD, pos, 1, 0.0, 0.0);
        particles(level, ParticleTypes.SOUL_FIRE_FLAME, pos, 2, 0.02, 0.0);
        // llama que sube y se arrastra hacia atrás
        Vec3 drift = look.scale(-0.25).add(0, 1.0, 0);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y + 0.03, pos.z, 0,
                drift.x, drift.y, drift.z, 0.07);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, pos.x, pos.y, pos.z, 0,
                drift.x * 0.5, drift.y, drift.z * 0.5, 0.11);
        // chispas
        if (now % 2 == 0) {
            particles(level, ParticleTypes.ELECTRIC_SPARK, pos, 2, 0.06, 0.0);
        }
    }

    /** Aura morada que gira alrededor del jugador mientras el karma está activo. */
    private static void karmaAura(ServerPlayer p, ServerLevel level, long now) {
        for (int i = 0; i < 4; i++) {
            double a = now * 0.2 + i * Math.PI / 2.0;
            Vec3 pos = p.position().add(Math.cos(a) * 0.7, 0.15 + (i % 2) * 0.9, Math.sin(a) * 0.7);
            particles(level, ParticleTypes.PORTAL, pos, 2, 0.05, 0.0);
        }
    }

    private static void badTimeAura(ServerPlayer p, ServerLevel level) {
        double radius = SansConfig.d("bad_time.radius");
        AABB box = p.getBoundingBox().inflate(radius);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> valid(p, x))) {
            if (e.getType().getCategory() == MobCategory.MONSTER) {
                e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 30, 2, false, false));
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false));
            }
        }
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8.0;
            Vec3 pos = p.position().add(Math.cos(a) * radius, 0.2, Math.sin(a) * radius);
            particles(level, ParticleTypes.SOUL_FIRE_FLAME, pos, 1, 0.05, 0.0);
        }
    }

    static void sendSync(ServerPlayer p, PlayerState st, long now) {
        int n = Ability.ALL.length;
        int[] remaining = new int[n];
        int[] total = new int[n];
        for (int i = 0; i < n; i++) {
            remaining[i] = (int) Math.max(0, st.cooldownEnd[i] - now);
            total[i] = st.cooldownTotal[i];
        }
        int unlocked = 0;
        for (Ability a : Ability.ALL) {
            if (st.isUnlocked(a)) unlocked |= 1 << a.ordinal();
        }
        int maxMana = Progression.maxMana(st);
        if (st.mana < 0) st.mana = maxMana;
        ServerPlayNetworking.send(p, new SyncPayload(remaining, total, st.fatigue,
                Progression.maxFatigue(st), st.dodgeOn, st.karmaOn,
                (int) Math.max(0, st.seriousUntil - now), (int) Math.max(0, st.badTimeUntil - now),
                Telekinesis.remaining(p, now), unlocked, (int) Math.round(st.mana), maxMana,
                Progression.slots(st), st.loadout, st.points, st.xp.clone(), st.nodes.clone()));
    }

    // =====================================================================
    //  Daño recibido: esquive automático y "Mal momento"
    // =====================================================================

    public static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (boosting || !(entity instanceof ServerPlayer player)) return true;
        if (!SansMod.hasCharm(player)) return true;

        ServerLevel level = (ServerLevel) player.level();
        MinecraftServer server = level.getServer();
        long now = server.getTickCount();
        PlayerState st = PlayerState.of(player);

        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return true; // vacío, /kill...

        // Mal momento: recibes más daño y no puedes esquivar
        if (st.badTimeUntil > now) {
            double mul = SansConfig.d("bad_time.damage_taken_multiplier");
            if (mul > 1.0001) {
                boosting = true;
                try {
                    player.hurtServer(level, source, (float) (amount * mul));
                } finally {
                    boosting = false;
                }
                return false;
            }
            return true;
        }

        if (!st.dodgeOn) return true;
        Entity attacker = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        if (attacker == null) return true; // caídas, fuego, hambre... no se esquivan

        if (now - st.lastDodgeTick <= SansConfig.i("dodge.window_ticks")) return false; // sigues esquivando
        if (st.fatigue >= Progression.maxFatigue(st)) return true;              // cansado

        st.fatigue++;
        st.lastDodgeTick = now;
        st.lastRecoverTick = now;

        Vec3 away = player.position().subtract(attacker.position());
        Vec3 flat = new Vec3(away.x, 0, away.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : flat.normalize();
        double sign = player.getRandom().nextBoolean() ? 1.0 : -1.0;
        Vec3 step = new Vec3(-flat.z, 0, flat.x).scale(2.0 * sign);
        Scheduler.later(server, 1, () -> sidestep(player, level, step));
        return false;
    }

    /**
     * Silueta celeste translúcida: almas (semitransparentes) y llamas azules con forma de cuerpo,
     * de los pies a la cabeza. Se usa como "eco" al esquivar y como aura mientras dura el esquive.
     */
    private static void dodgeAura(ServerLevel level, Vec3 base) {
        double[][] body = {{0.25, 0.16}, {0.70, 0.19}, {1.10, 0.23}, {1.40, 0.23}, {1.75, 0.15}}; // {altura, grosor}
        for (double[] part : body) {
            Vec3 at = base.add(0, part[0], 0);
            particles(level, ParticleTypes.SOUL, at, 1, part[1], 0.0);
            particles(level, ParticleTypes.SOUL_FIRE_FLAME, at, 1, part[1] * 0.8, 0.0);
        }
    }

    private static void sidestep(ServerPlayer player, ServerLevel level, Vec3 step) {
        if (!player.isAlive()) return;
        for (Vec3 s : new Vec3[] {step, step.scale(-1.0)}) {
            Vec3 moved = sweep(level, player, s);
            if (moved.length() >= 0.9) {
                Vec3 from = player.position();
                Vec3 dest = from.add(moved);
                // eco celeste translúcido que se queda donde estabas y se desvanece
                MinecraftServer srv = level.getServer();
                for (int k = 0; k < 6; k++) {
                    Scheduler.later(srv, k * 3, () -> dodgeAura(level, from));
                }
                particles(level, ParticleTypes.POOF, from.add(0, 1, 0), 8, 0.3, 0.02);
                player.connection.teleport(dest.x, dest.y, dest.z, player.getYRot(), player.getXRot());
                particles(level, ParticleTypes.POOF, dest.add(0, 1, 0), 8, 0.3, 0.02);
                sound(level, dest, SoundEvents.ENDERMAN_TELEPORT, 0.7f, 1.6f);
                return;
            }
        }
        sound(level, player.position(), SoundEvents.ENDERMAN_TELEPORT, 0.7f, 1.6f);
    }
}
