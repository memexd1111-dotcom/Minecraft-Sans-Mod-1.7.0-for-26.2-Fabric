package com.benja.sansmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;

public class SansMod implements ModInitializer {
    public static final String MOD_ID = "sansmod";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    /** true si el jugador lleva el amuleto en cualquier lugar del inventario (incluida la mano secundaria). */
    public static boolean hasCharm(Player player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.SANS_CHARM)) return true;
        }
        return false;
    }

    @Override
    public void onInitialize() {
        SansConfig.load();
        PlayerState.init();
        ModBlocks.initialize();
        ModItems.initialize();

        PayloadTypeRegistry.clientboundPlay().register(SyncPayload.TYPE, SyncPayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(ShakePayload.TYPE, ShakePayload.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenTablePayload.TYPE, OpenTablePayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(CastPayload.TYPE, CastPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(TableActionPayload.TYPE, TableActionPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(UpgradePayload.TYPE, UpgradePayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(TableActionPayload.TYPE,
                (payload, context) -> TableLogic.handle(context.player(), payload.insert(), payload.ability()));
        ServerPlayNetworking.registerGlobalReceiver(UpgradePayload.TYPE,
                (payload, context) -> Progression.buy(context.player(), PlayerState.of(context.player()), payload.node()));
        ServerPlayNetworking.registerGlobalReceiver(CastPayload.TYPE,
                (payload, context) -> AbilityLogic.cast(context.player(), payload.ability(), payload.charge()));

        ServerTickEvents.END_SERVER_TICK.register(AbilityLogic::serverTick);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(AbilityLogic::allowDamage);
        ServerLivingEntityEvents.AFTER_DEATH.register(BoneDrops::onDeath);
        ServerEntityEvents.ENTITY_LOAD.register(SansMobs::onLoad);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            AbilityLogic.saveAll(server);
            Telekinesis.releaseAll();
            Karma.clear();
            SansMobs.clear();
            Scheduler.clear();
            PlayerState.clear();
        });
    }
}
