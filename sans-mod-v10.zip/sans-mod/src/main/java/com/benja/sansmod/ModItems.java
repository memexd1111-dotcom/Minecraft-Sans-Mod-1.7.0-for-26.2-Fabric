package com.benja.sansmod;

import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.consume_effects.ApplyStatusEffectsConsumeEffect;

public final class ModItems {
    private static final FoodProperties HOT_DOG_FOOD = new FoodProperties.Builder()
            .nutrition(6)
            .saturationModifier(0.8f)
            .alwaysEdible()
            .build();

    private static final Consumable HOT_DOG_CONSUMABLE = Consumables.defaultFood()
            .onConsume(new ApplyStatusEffectsConsumeEffect(
                    new MobEffectInstance(MobEffects.REGENERATION, 10 * 20, 1), 1.0f))
            .build();

    /** El objeto que da las habilidades. */
    public static final Item SANS_CHARM = register("sans_charm", Item::new,
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    // Objetos de habilidad: se inscriben en el amuleto con la Mesa de Sans (cada uno desbloquea una habilidad).
    public static final Item BLUE_BONE = register("blue_bone", Item::new, new Item.Properties().rarity(Rarity.UNCOMMON));
    public static final Item ORANGE_BONE = register("orange_bone", Item::new, new Item.Properties().rarity(Rarity.UNCOMMON));
    public static final Item KARMA_ESSENCE = register("karma_essence", Item::new, new Item.Properties().rarity(Rarity.RARE));
    public static final Item ANCIENT_RIB = register("ancient_rib", Item::new, new Item.Properties().rarity(Rarity.UNCOMMON));
    public static final Item BROKEN_CLOCK = register("broken_clock", Item::new, new Item.Properties().rarity(Rarity.RARE));
    public static final Item BURNING_EYE = register("burning_eye", Item::new, new Item.Properties().rarity(Rarity.RARE));
    public static final Item GASTER_SHARD = register("gaster_shard", Item::new, new Item.Properties().rarity(Rarity.RARE));
    public static final Item GASTER_CROWN = register("gaster_crown", Item::new, new Item.Properties().rarity(Rarity.EPIC));
    public static final Item TELEKINETIC_PEARL = register("telekinetic_pearl", Item::new, new Item.Properties().rarity(Rarity.RARE));

    public static final Item HOT_DOG = register("hot_dog", Item::new,
            new Item.Properties().food(HOT_DOG_FOOD, HOT_DOG_CONSUMABLE));

    // Objetos "de adorno": solo se usan como modelo en las cabezas de los armor stands invisibles.
    public static final Item BONE_PROJECTILE = register("bone_projectile", Item::new, new Item.Properties());
    public static final Item BONE_WALL = register("bone_wall", Item::new, new Item.Properties());
    public static final Item BLASTER_SKULL = register("blaster_skull", Item::new, new Item.Properties());
    public static final Item BLASTER_SKULL_HALF = register("blaster_skull_half", Item::new, new Item.Properties());
    public static final Item BLASTER_SKULL_OPEN = register("blaster_skull_open", Item::new, new Item.Properties());
    public static final Item BLUE_BONE_PROJECTILE = register("blue_bone_projectile", Item::new, new Item.Properties());
    public static final Item ORANGE_BONE_PROJECTILE = register("orange_bone_projectile", Item::new, new Item.Properties());

    private ModItems() {}

    private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, SansMod.id(name));
        Item item = factory.apply(props.setId(key));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(tab -> {
            tab.accept(SANS_CHARM);
            tab.accept(ModBlocks.SANS_TABLE.asItem());
            tab.accept(BLUE_BONE);
            tab.accept(ORANGE_BONE);
            tab.accept(KARMA_ESSENCE);
            tab.accept(ANCIENT_RIB);
            tab.accept(BROKEN_CLOCK);
            tab.accept(BURNING_EYE);
            tab.accept(GASTER_SHARD);
            tab.accept(GASTER_CROWN);
            tab.accept(TELEKINETIC_PEARL);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(tab -> tab.accept(HOT_DOG));
    }
}
