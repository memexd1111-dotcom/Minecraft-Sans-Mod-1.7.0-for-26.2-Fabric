package com.benja.sansmod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Telequinesis controlable: al usarla agarras al objetivo que miras y lo mueves con la mirada
 * (se queda a la distancia a la que lo agarraste). Si lo estrellas contra un muro o el suelo a
 * buena velocidad recibe daño. Al usarla otra vez lo lanzas hacia donde miras.
 */
public final class Telekinesis {
    private static final class Grab {
        final LivingEntity target;
        final boolean hadNoGravity;
        double distance;
        long endTick;
        boolean thrown;
        boolean cooldownStarted;
        Vec3 lastPos;
        Vec3 lastDir;
        double lastSpeed;
        long nextImpact;

        Grab(LivingEntity target, boolean hadNoGravity, double distance) {
            this.target = target;
            this.hadNoGravity = hadNoGravity;
            this.distance = distance;
        }
    }

    private static final Map<UUID, Grab> GRABS = new HashMap<>();

    private Telekinesis() {}

    /** Ticks que le quedan al agarre (0 si no sujetas a nadie). */
    public static int remaining(ServerPlayer p, long now) {
        Grab g = GRABS.get(p.getUUID());
        return g == null || g.thrown ? 0 : (int) Math.max(0, g.endTick - now);
    }

    /** true si el jugador tiene a alguien agarrado (todavía sin lanzar). */
    public static boolean isHolding(ServerPlayer p) {
        Grab g = GRABS.get(p.getUUID());
        return g != null && !g.thrown;
    }

    // =====================================================================
    //  Agarrar
    // =====================================================================

    public static boolean start(ServerPlayer p, ServerLevel level, PlayerState st, long now) {
        double range = SansConfig.d("telekinesis.range");
        AbilityLogic.Hit hit = AbilityLogic.trace(level, p, p.getEyePosition(), p.getLookAngle(), range);
        LivingEntity target = hit.entity();
        if (target == null) {
            AbilityLogic.msg(p, Component.translatable("msg.sansmod.no_target"));
            return false;
        }

        // si otro jugador ya lo tiene agarrado, respetamos el estado de gravedad original
        boolean hadNoGravity = target.isNoGravity();
        for (Grab other : GRABS.values()) {
            if (other.target == target && !other.thrown) hadNoGravity = other.hadNoGravity;
        }

        Vec3 center = target.position().add(0, target.getBbHeight() / 2.0, 0);
        double dist = Math.max(3.0, Math.min(range, p.getEyePosition().distanceTo(center)));
        Grab g = new Grab(target, hadNoGravity, dist);
        g.endTick = now + Math.max(1L, Math.round(Progression.holdSeconds(st) * 20.0));
        g.lastPos = target.position();
        target.setNoGravity(true);
        GRABS.put(p.getUUID(), g);

        AbilityLogic.sound(level, target.position(), SoundEvents.EVOKER_CAST_SPELL, 1.0f, 1.2f);
        AbilityLogic.msg(p, Component.translatable("msg.sansmod.tk_hold"));
        return true;
    }

    // =====================================================================
    //  Lanzar (segundo uso)
    // =====================================================================

    public static void release(ServerPlayer p, ServerLevel level, PlayerState st, long now) {
        Grab g = GRABS.get(p.getUUID());
        if (g == null || g.thrown) return;
        LivingEntity t = g.target;
        t.setNoGravity(g.hadNoGravity);
        if (t.isAlive()) {
            t.setDeltaMovement(p.getLookAngle().scale(SansConfig.d("telekinesis.throw_speed")));
            t.hurtMarked = true;
            AbilityLogic.sound(level, t.position(), SoundEvents.EVOKER_CAST_SPELL, 1.0f, 0.7f);
        }
        g.thrown = true;
        g.endTick = now + 40; // seguimos vigilando el choque unos instantes
        g.lastPos = t.position();
        g.lastDir = null;
        g.lastSpeed = 0;
        startCooldown(p, st, g, now);
        AbilityLogic.msg(p, Component.translatable("msg.sansmod.tk_throw"));
    }

    private static void startCooldown(ServerPlayer p, PlayerState st, Grab g, long now) {
        if (g.cooldownStarted) return;
        g.cooldownStarted = true;
        AbilityLogic.startCooldown(p, st, Ability.TELEKINESIS, now);
    }

    // =====================================================================
    //  Tick del servidor
    // =====================================================================

    public static void tick(MinecraftServer server, long now) {
        if (GRABS.isEmpty()) return;
        for (Map.Entry<UUID, Grab> e : new ArrayList<>(GRABS.entrySet())) {
            Grab g = e.getValue();
            ServerPlayer p = findPlayer(server, e.getKey());
            LivingEntity t = g.target;

            boolean over = p == null || !p.isAlive() || p.isSpectator()
                    || !t.isAlive() || t.isRemoved() || t.level() != p.level() || now >= g.endTick;
            if (over) {
                finish(e.getKey(), g, p, now);
                continue;
            }

            ServerLevel level = (ServerLevel) p.level();
            PlayerState st = PlayerState.of(p);
            detectImpact(p, level, st, g, now);
            if (!g.thrown && GRABS.get(e.getKey()) == g) {
                steer(p, level, g, now);
            }
        }
    }

    private static ServerPlayer findPlayer(MinecraftServer server, UUID id) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.getUUID().equals(id)) return p;
        }
        return null;
    }

    private static void finish(UUID owner, Grab g, ServerPlayer p, long now) {
        if (!g.thrown) {
            g.target.setNoGravity(g.hadNoGravity);
        }
        if (p != null) {
            startCooldown(p, PlayerState.of(p), g, now);
        }
        GRABS.remove(owner);
    }

    /** Mueve al objetivo hacia el punto que mira el jugador (a la distancia del agarre). */
    private static void steer(ServerPlayer p, ServerLevel level, Grab g, long now) {
        LivingEntity t = g.target;
        // agachado = acercar al objetivo, corriendo = alejarlo
        double adj = SansConfig.d("telekinesis.adjust_speed");
        if (p.isShiftKeyDown()) {
            g.distance = Math.max(SansConfig.d("telekinesis.min_distance"), g.distance - adj);
        } else if (p.isSprinting()) {
            g.distance = Math.min(SansConfig.d("telekinesis.range"), g.distance + adj);
        }
        Vec3 desired = p.getEyePosition().add(p.getLookAngle().scale(g.distance));
        Vec3 center = t.position().add(0, t.getBbHeight() / 2.0, 0);
        Vec3 v = desired.subtract(center).scale(0.6);
        double max = Math.max(0.2, SansConfig.d("telekinesis.max_speed"));
        double len = v.length();
        if (len > max) v = v.scale(max / len);

        t.setDeltaMovement(v);
        t.hurtMarked = true;

        if (now % 2 == 0) {
            AbilityLogic.particles(level, ParticleTypes.SOUL_FIRE_FLAME, center, 4, 0.4, 0.02);
            // marca: un anillo luminoso que gira sobre la cabeza del objetivo
            Vec3 top = t.position().add(0, t.getBbHeight() + 0.45, 0);
            for (int i = 0; i < 6; i++) {
                double a = now * 0.25 + i * Math.PI / 3.0;
                AbilityLogic.particles(level, ParticleTypes.END_ROD, top.add(Math.cos(a) * 0.4, 0, Math.sin(a) * 0.4), 1, 0.0, 0.0);
            }
        }
    }

    /**
     * Compara cuánto se movió el objetivo en el último tick con cuánto venía moviéndose: si iba
     * rápido y de golpe casi no avanzó, chocó con un muro, el techo o el suelo.
     */
    private static void detectImpact(ServerPlayer p, ServerLevel level, PlayerState st, Grab g, long now) {
        LivingEntity t = g.target;
        Vec3 pos = t.position();
        Vec3 moved = pos.subtract(g.lastPos);
        double speed = moved.length();
        double min = SansConfig.d("telekinesis.min_impact_speed");

        if (g.lastDir != null && g.lastSpeed >= min && now >= g.nextImpact) {
            double along = moved.dot(g.lastDir);
            if (along < g.lastSpeed * 0.4) {
                double factor = Math.max(0.4, Math.min(1.6, g.lastSpeed / 1.2));
                float dmg = (float) (Progression.dmg(st, Ability.TELEKINESIS, SansConfig.d("telekinesis.slam_damage")) * factor);
                Vec3 at = pos.add(0, t.getBbHeight() / 2.0, 0);
                AbilityLogic.hurt(level, p, t, dmg, st);
                AbilityLogic.particles(level, ParticleTypes.POOF, at, 18, 0.5, 0.1);
                AbilityLogic.particles(level, ParticleTypes.ELECTRIC_SPARK, at, 10, 0.4, 0.2);
                AbilityLogic.sound(level, pos, SoundEvents.BONE_BLOCK_BREAK, 1.4f, 0.6f);
                AbilityLogic.shake(level, pos, 20.0, (float) (0.8 + 0.8 * Math.min(1.0, g.lastSpeed / 1.6)), 8);
                if (t.isAlive()) {
                    t.setDeltaMovement(Vec3.ZERO);
                    t.hurtMarked = true;
                }
                g.nextImpact = now + 20;
                speed = 0;
            }
        }
        g.lastPos = t.position();
        g.lastSpeed = speed;
        g.lastDir = speed > 1.0E-4 ? moved.scale(1.0 / speed) : null;
    }

    /** Al cerrar el mundo: devuelve la gravedad a quien siga agarrado. */
    public static void releaseAll() {
        for (Grab g : GRABS.values()) {
            if (!g.thrown) g.target.setNoGravity(g.hadNoGravity);
        }
        GRABS.clear();
    }
}
