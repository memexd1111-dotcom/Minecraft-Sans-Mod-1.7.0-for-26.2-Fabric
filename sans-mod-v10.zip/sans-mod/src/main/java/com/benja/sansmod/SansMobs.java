package com.benja.sansmod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Variantes de mobs vanilla que sueltan los objetos de habilidad:
 * Esqueleto Kármico y Espectro del Reloj (Nether), Enderman Telequinético y Vigía de Gaster (End), y
 * Esqueletos de Sans (cualquier dimensión) que atacan con huesos azules y naranjas.
 * Son mobs normales con una etiqueta, nombre, aura y ataques propios (no tienen modelo nuevo).
 */
public final class SansMobs {
    private SansMobs() {}

    public enum Variant {
        KARMA_SKELETON("karma_skeleton", ParticleTypes.PORTAL),
        CLOCK_SPECTER("clock_specter", ParticleTypes.ELECTRIC_SPARK),
        TELEKINETIC_ENDERMAN("telekinetic_enderman", ParticleTypes.END_ROD),
        GASTER_WATCHER("gaster_watcher", ParticleTypes.SOUL_FIRE_FLAME),
        SANS_SKELETON("sans_skeleton", ParticleTypes.SOUL_FIRE_FLAME);

        public final String id;
        final ParticleOptions aura;

        Variant(String id, ParticleOptions aura) {
            this.id = id;
            this.aura = aura;
        }

        public String tag() {
            return "sansmod_" + id;
        }
    }

    private static final String CHECKED = "sansmod_checked";
    private static final List<LivingEntity> TRACKED = new ArrayList<>();
    private static final Map<UUID, Long> NEXT_ATTACK = new HashMap<>();

    // En 26.x Entity#getTags() ya no existe con ese nombre. Se resuelve por
    // reflexion (sin ofuscacion los nombres son los mismos en juego y en dev),
    // probando los nombres conocidos y, si no, cualquier metodo sin parametros
    // que devuelva un Set<String> con las etiquetas de la entidad.
    private static java.lang.reflect.Method tagsMethod;
    private static boolean tagsSearched;

    private static java.lang.reflect.Method findTagsMethod(Entity e) {
        if (tagsSearched) return tagsMethod;
        tagsSearched = true;
        for (String n : new String[] {"getTags", "entityTags", "tags", "getEntityTags"}) {
            try {
                var m = Entity.class.getMethod(n);
                if (java.util.Set.class.isAssignableFrom(m.getReturnType())) {
                    tagsMethod = m;
                    return m;
                }
            } catch (ReflectiveOperationException ignored) {
            }
        }
        for (var m : Entity.class.getMethods()) {
            if (m.getParameterCount() != 0 || !java.util.Set.class.isAssignableFrom(m.getReturnType())) continue;
            if (!m.getGenericReturnType().getTypeName().contains("String")) continue;
            if (!m.getName().toLowerCase().contains("tag")) continue;
            tagsMethod = m;
            return m;
        }
        return null;
    }

    static boolean hasTag(Entity e, String tag) {
        try {
            var m = findTagsMethod(e);
            if (m != null) return ((java.util.Set<?>) m.invoke(e)).contains(tag);
        } catch (ReflectiveOperationException ignored) {
        }
        return false;
    }

    public static Variant variantOf(Entity e) {
        for (Variant v : Variant.values()) {
            if (hasTag(e, v.tag())) return v;
        }
        return null;
    }

    public static void clear() {
        TRACKED.clear();
        NEXT_ATTACK.clear();
    }

    // =====================================================================
    //  Aparición: algunos mobs vanilla se convierten en variantes
    // =====================================================================

    public static void onLoad(Entity entity, ServerLevel level) {
        if (!(entity instanceof LivingEntity mob) || !SansConfig.b("mobs.enabled")) return;
        Variant existing = variantOf(mob);
        if (existing != null) {
            track(mob);
            return;
        }
        if (hasTag(mob, CHECKED)) return;

        var type = mob.getType();
        boolean nether = level.dimension() == Level.NETHER;
        boolean end = level.dimension() == Level.END;
        Variant pick = null;
        double r = ThreadLocalRandom.current().nextDouble();
        double chance = SansConfig.d("mobs.variant_chance");
        if (nether && type == EntityTypes.WITHER_SKELETON && r < chance) pick = Variant.KARMA_SKELETON;
        else if (nether && type == EntityTypes.BLAZE && r < chance) pick = Variant.CLOCK_SPECTER;
        else if (end && type == EntityTypes.ENDERMAN && r < chance) pick = Variant.TELEKINETIC_ENDERMAN;
        else if (end && type == EntityTypes.SHULKER && r < chance) pick = Variant.GASTER_WATCHER;
        else if ((type == EntityTypes.SKELETON || type == EntityTypes.STRAY || type == EntityTypes.BOGGED)
                && r < SansConfig.d("mobs.sans_skeleton_chance")) {
            pick = Variant.SANS_SKELETON;
        }
        mob.addTag(CHECKED);
        if (pick == null) return;

        mob.addTag(pick.tag());
        if (pick != Variant.SANS_SKELETON) {
            mob.setCustomName(Component.translatable("mob.sansmod." + pick.id));
            mob.setCustomNameVisible(true);
            mob.setGlowingTag(true);
            mob.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, -1, 3));
            mob.addEffect(new MobEffectInstance(MobEffects.REGENERATION, -1, 0));
        }
        track(mob);
    }

    private static void track(LivingEntity mob) {
        if (!TRACKED.contains(mob)) TRACKED.add(mob);
    }

    // =====================================================================
    //  Tick: aura y ataques
    // =====================================================================

    public static void tick(MinecraftServer server, long now) {
        if (TRACKED.isEmpty()) return;
        int interval = Math.max(40, SansConfig.i("mobs.attack_interval_ticks"));
        for (LivingEntity mob : new ArrayList<>(TRACKED)) {
            if (!mob.isAlive() || mob.isRemoved() || !(mob.level() instanceof ServerLevel level)) {
                TRACKED.remove(mob);
                NEXT_ATTACK.remove(mob.getUUID());
                continue;
            }
            Variant v = variantOf(mob);
            if (v == null) continue;
            if (now % 8 == 0) {
                AbilityLogic.particles(level, v.aura, mob.position().add(0, mob.getBbHeight() * 0.5, 0), 2, 0.4, 0.0);
            }
            long next = NEXT_ATTACK.getOrDefault(mob.getUUID(), now + interval / 2 + ThreadLocalRandom.current().nextInt(interval));
            NEXT_ATTACK.put(mob.getUUID(), next);
            if (now < next) continue;

            ServerPlayer target = nearestPlayer(level, mob, 22.0);
            if (target == null) continue;
            attack(server, level, mob, v, target);
            NEXT_ATTACK.put(mob.getUUID(), now + interval / 2 + ThreadLocalRandom.current().nextInt(interval));
        }
    }

    private static ServerPlayer nearestPlayer(ServerLevel level, LivingEntity mob, double range) {
        ServerPlayer best = null;
        double bestD = range * range;
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            if (p.level() != level || !p.isAlive() || p.isSpectator() || p.isCreative()) continue;
            double d = p.distanceToSqr(mob);
            if (d < bestD && mob.hasLineOfSight(p)) {
                best = p;
                bestD = d;
            }
        }
        return best;
    }

    private static void attack(MinecraftServer server, ServerLevel level, LivingEntity mob, Variant v, ServerPlayer target) {
        switch (v) {
            case SANS_SKELETON -> bones(server, level, mob, target, ThreadLocalRandom.current().nextBoolean() ? 1 : 2, 3);
            case KARMA_SKELETON -> {
                bones(server, level, mob, target, 1, 5);
                bones(server, level, mob, target, 2, 5);
            }
            case CLOCK_SPECTER -> {
                // el tiempo se ralentiza: lentitud + huesos azules (hay que seguir moviéndose)
                target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
                AbilityLogic.particles(level, ParticleTypes.ELECTRIC_SPARK, target.position().add(0, 1, 0), 20, 0.6, 0.1);
                AbilityLogic.sound(level, target.position(), SoundEvents.BEACON_DEACTIVATE, 1.0f, 0.6f);
                bones(server, level, mob, target, 1, 4);
            }
            case TELEKINETIC_ENDERMAN -> {
                // levanta al jugador un instante y lo suelta
                target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 24, 1));
                AbilityLogic.particles(level, ParticleTypes.END_ROD, target.position().add(0, 1, 0), 25, 0.5, 0.05);
                AbilityLogic.sound(level, target.position(), SoundEvents.EVOKER_CAST_SPELL, 1.0f, 0.7f);
            }
            case GASTER_WATCHER -> pillar(server, level, mob, target);
        }
    }

    /**
     * Huesos hacia el jugador. kind: 0 normal, 1 azul (solo daña si te mueves), 2 naranja (solo si estás quieto).
     */
    private static void bones(MinecraftServer server, ServerLevel level, LivingEntity mob, ServerPlayer target, int kind, int count) {
        Item model = kind == 1 ? ModItems.BLUE_BONE_PROJECTILE : kind == 2 ? ModItems.ORANGE_BONE_PROJECTILE : ModItems.BONE_PROJECTILE;
        Vec3 from = mob.position().add(0, mob.getBbHeight() * 0.7, 0);
        Vec3 aim = target.position().add(0, target.getBbHeight() * 0.5, 0);
        Vec3 base = aim.subtract(from).normalize();
        double speed = 1.1;
        float dmg = (float) SansConfig.d("mobs.attack_damage");
        AbilityLogic.sound(level, from, SoundEvents.SKELETON_SHOOT, 1.0f, kind == 1 ? 1.4f : 0.9f);
        for (int k = 0; k < count; k++) {
            Vec3 dir = base.yRot((float) ((k - (count - 1) / 2.0) * 0.16)).normalize();
            Vec3 start = from.add(dir.scale(0.8));
            int ticks = Math.max(1, (int) Math.ceil(from.distanceTo(aim) / speed));
            LivingEntity stand = AbilityLogic.makeStand(level, start, (float) Math.toDegrees(Math.atan2(-dir.x, dir.z)), new ItemStack(model));
            for (int t = 1; t <= ticks; t++) {
                final int tt = t;
                Scheduler.later(server, t, () -> AbilityLogic.moveStand(stand, start.add(dir.scale(speed * tt))));
            }
            Scheduler.later(server, ticks + 1, () -> {
                if (stand != null) stand.discard();
            });
            final Vec3[] before = new Vec3[1];
            Scheduler.later(server, Math.max(0, ticks - 4), () -> before[0] = target.position());
            Scheduler.later(server, ticks, () -> {
                if (!target.isAlive() || !mob.isAlive()) return;
                // el golpe solo cuenta si el último trecho del hueso llega cerca del jugador
                if (target.position().add(0, 1, 0).distanceTo(start.add(dir.scale(speed * ticks))) > 2.2) return;
                boolean moving = before[0] != null && target.position().distanceToSqr(before[0]) > 0.0225;
                boolean hits = kind == 0 || (kind == 1 && moving) || (kind == 2 && !moving);
                if (hits) {
                    target.invulnerableTime = 0;
                    target.hurtServer(level, level.damageSources().mobAttack(mob), dmg);
                    AbilityLogic.particles(level, kind == 2 ? ParticleTypes.FLAME : ParticleTypes.SOUL_FIRE_FLAME,
                            target.position().add(0, 1, 0), 10, 0.3, 0.05);
                }
            });
        }
    }

    /** Pilar de energía: un círculo avisa en el suelo y, si sigues dentro, te golpea. */
    private static void pillar(MinecraftServer server, ServerLevel level, LivingEntity mob, ServerPlayer target) {
        Vec3 center = target.position();
        int warn = 24;
        AbilityLogic.sound(level, center, SoundEvents.BEACON_POWER_SELECT, 1.0f, 1.5f);
        for (int w = 0; w < warn; w += 3) {
            final double frac = w / (double) warn;
            Scheduler.later(server, w, () -> {
                double r = 0.4 + 1.6 * (1.0 - frac);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4.0;
                    AbilityLogic.particles(level, ParticleTypes.SOUL_FIRE_FLAME,
                            new Vec3(center.x + Math.cos(a) * r, center.y + 0.1, center.z + Math.sin(a) * r), 1, 0.02, 0.0);
                }
            });
        }
        Scheduler.later(server, warn, () -> {
            for (double y = 0; y <= 7.0; y += 0.8) {
                AbilityLogic.particles(level, ParticleTypes.END_ROD, center.add(0, y, 0), 3, 0.3, 0.02);
                AbilityLogic.particles(level, ParticleTypes.SOUL_FIRE_FLAME, center.add(0, y, 0), 2, 0.6, 0.0);
            }
            AbilityLogic.particles(level, ParticleTypes.EXPLOSION, center.add(0, 0.5, 0), 1, 0.0, 0.0);
            AbilityLogic.sound(level, center, SoundEvents.WARDEN_SONIC_BOOM, 1.2f, 1.0f);
            AbilityLogic.shake(level, center, 18.0, 1.2f, 8);
            AABB box = new AABB(center.x - 2.0, center.y - 1.0, center.z - 2.0, center.x + 2.0, center.y + 5.0, center.z + 2.0);
            for (ServerPlayer p : level.getEntitiesOfClass(ServerPlayer.class, box)) {
                if (!p.isAlive() || p.isSpectator()) continue;
                p.invulnerableTime = 0;
                p.hurtServer(level, level.damageSources().mobAttack(mob), (float) (SansConfig.d("mobs.attack_damage") * 1.6));
            }
        });
    }
}
