package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.Progression;
import com.benja.sansmod.UpgradePayload;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Árbol de mejoras: gasta los puntos que ganas al subir de nivel las habilidades. */
public class TreeScreen extends Screen {
    private static final int W = 112;
    private static final int H = 22;
    private static final int ROWH = 32;
    private final List<Button> buttons = new ArrayList<>();
    private int cx;
    private int top;

    public TreeScreen() {
        super(Component.translatable("screen.sansmod.tree_title"));
    }

    private int nodeX(int col) {
        return cx + (col - 1) * (W + 18) - W / 2;
    }

    private int nodeY(int row) {
        return top + row * ROWH;
    }

    @Override
    protected void init() {
        cx = this.width / 2;
        top = 58;
        buttons.clear();
        for (int i = 0; i < Progression.NODES.length; i++) {
            final int node = i;
            Progression.Node n = Progression.NODES[i];
            Button b = Button.builder(Component.empty(),
                    btn -> ClientPlayNetworking.send(new UpgradePayload(node)))
                    .bounds(nodeX(n.col()), nodeY(n.row()), W, H).build();
            buttons.add(b);
            addRenderableWidget(b);
        }
    }

    private static boolean prereqOk(Progression.Node n) {
        return n.requires() < 0 || ClientState.nodes[n.requires()] >= n.requiredRank();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        for (int i = 0; i < Progression.NODES.length; i++) {
            Progression.Node n = Progression.NODES[i];
            buttons.get(i).setMessage(Component.translatable("node.sansmod." + n.id() + ".name")
                    .append(Component.literal("  " + ClientState.nodes[i] + "/" + n.max())));
        }
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        g.text(this.font, this.title, (this.width - this.font.width(this.title)) / 2, 10, 0xFFFFFFFF, true);
        Component pts = Component.translatable("screen.sansmod.points", ClientState.points);
        g.text(this.font, pts, (this.width - this.font.width(pts)) / 2, 24, 0xFFFFDD55, true);

        String[] branches = {"attack", "utility", "soul"};
        for (int c = 0; c < 3; c++) {
            Component t = Component.translatable("screen.sansmod.branch." + branches[c]);
            g.text(this.font, t, nodeX(c) + (W - this.font.width(t)) / 2, 42, 0xFF99DDFF, false);
        }

        int hovered = -1;
        for (int i = 0; i < Progression.NODES.length; i++) {
            Progression.Node n = Progression.NODES[i];
            int x = nodeX(n.col());
            int y = nodeY(n.row());
            if (n.requires() >= 0) { // línea hasta el nodo requerido
                Progression.Node r = Progression.NODES[n.requires()];
                int lx = x + W / 2;
                g.fill(lx, nodeY(r.row()) + H, lx + 1, y, prereqOk(n) ? 0xFF77FF77 : 0xFF666666);
            }
            boolean maxed = ClientState.nodes[i] >= n.max();
            boolean buyable = !maxed && ClientState.points > 0 && prereqOk(n);
            g.outline(x - 1, y - 1, W + 2, H + 2, maxed ? 0xFFFFDD55 : buyable ? 0xFF77FF77 : prereqOk(n) ? 0xFF888888 : 0xFFCC4444);
            if (mouseX >= x && mouseX < x + W && mouseY >= y && mouseY < y + H) hovered = i;
        }

        int y = nodeY(4) + 6;
        if (hovered >= 0) {
            Progression.Node n = Progression.NODES[hovered];
            Component d = Component.translatable("node.sansmod." + n.id() + ".desc");
            g.text(this.font, d, (this.width - this.font.width(d)) / 2, y, 0xFFDDDDDD, false);
            if (!prereqOk(n)) {
                Component need = Component.translatable("msg.sansmod.node_locked");
                g.text(this.font, need, (this.width - this.font.width(need)) / 2, y + 11, 0xFFFF7777, false);
            }
        }
        // niveles de las habilidades
        y += 26;
        int col = 0;
        for (Ability a : Ability.ALL) {
            int xp = ClientState.xp[a.ordinal()];
            int lvl = Progression.level(xp);
            Component line = Component.translatable("ability.sansmod." + a.id)
                    .append(Component.literal(" Nv " + lvl + (lvl >= Progression.maxLevel() ? " (max)" : "  (" + xp + ")")));
            int lx = cx - 160 + (col % 2) * 170;
            if (!a.toggle) g.text(this.font, line, lx, y + (col / 2) * 10, ClientState.isUnlocked(a.ordinal()) ? 0xFFAAAAAA : 0xFF666666, false);
            if (!a.toggle) col++;
        }
    }
}
