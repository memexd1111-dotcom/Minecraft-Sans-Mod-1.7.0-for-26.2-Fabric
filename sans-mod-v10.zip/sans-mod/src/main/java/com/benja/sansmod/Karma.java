package com.benja.sansmod;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * KR (retribución kármica) como en Undertale: cada golpe con el karma activo suma una carga que hace
 * daño cada pocos ticks IGNORANDO la invulnerabilidad corta, hasta que se acaba el tiempo.
 */
public final class Karma {
    private static final class Entry {
        final LivingEntity target;
        final UUID owner;
        int stacks;
        long end;
        long next;

        Entry(LivingEntity target, UUID owner) {
            this.target = target;
            this.owner = owner;
        }
    }

    private static final Map<UUID, Entry> ACTIVE = new HashMap<>();

    private Karma() {}

    public static void apply(ServerPlayer owner, LivingEntity target, long now) {
        Entry e = ACTIVE.computeIfAbsent(target.getUUID(), id -> new Entry(target, owner.getUUID()));
        int max = Math.max(1, SansConfig.i("karma.kr_max_stacks"));
        e.stacks = Math.min(max, e.stacks + 1);
        e.end = now + Math.round(Progression.krSeconds(PlayerState.of(owner)) * 20.0);
        int interval = Math.max(2, SansConfig.i("karma.kr_interval_ticks"));
        if (e.next < now || e.next > now + interval) e.next = now + interval;
    }

    public static void tick(MinecraftServer server, long now) {
        if (ACTIVE.isEmpty()) return;
        int interval = Math.max(2, SansConfig.i("karma.kr_interval_ticks"));
        for (Map.Entry<UUID, Entry> me : new ArrayList<>(ACTIVE.entrySet())) {
            Entry e = me.getValue();
            LivingEntity t = e.target;
            if (!t.isAlive() || t.isRemoved() || now >= e.end) {
                ACTIVE.remove(me.getKey());
                continue;
            }
            if (now < e.next) continue;
            e.next = now + interval;

            ServerPlayer owner = null;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.getUUID().equals(e.owner)) owner = p;
            }
            if (owner == null || !(t.level() instanceof ServerLevel level)) {
                ACTIVE.remove(me.getKey());
                continue;
            }
            AbilityLogic.hurtPlain(level, owner, t, (float) (SansConfig.d("karma.kr_damage") * e.stacks
                    * Progression.krDamageMul(PlayerState.of(owner))));
            Vec3 at = t.position().add(0, t.getBbHeight() * 0.6, 0);
            AbilityLogic.particles(level, ParticleTypes.PORTAL, at, 6, 0.3, 0.2);
            AbilityLogic.particles(level, ParticleTypes.ELECTRIC_SPARK, at, 2, 0.25, 0.1);
        }
    }

    public static void clear() {
        ACTIVE.clear();
    }
}
