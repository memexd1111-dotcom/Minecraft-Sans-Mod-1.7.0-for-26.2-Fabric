package com.benja.sansmod;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;

/** Niveles de habilidad, puntos y árbol de mejoras. */
public final class Progression {
    private Progression() {}

    /** Nodo del árbol: id, rangos máximos, nodo requerido (-1 = ninguno), rango requerido, columna y fila. */
    public record Node(String id, int max, int requires, int requiredRank, int col, int row) {}

    public static final int POWER = 0, KR = 1, COOLDOWN = 2, SLOTS = 3, DODGE = 4, TELEKINESIS = 5, MANA = 6, REGEN = 7;
    public static final Node[] NODES = {
            new Node("power", 5, -1, 0, 0, 0),       // Ataque
            new Node("kr", 3, POWER, 2, 0, 1),
            new Node("cooldown", 5, -1, 0, 1, 0),    // Utilidad
            new Node("slots", 3, COOLDOWN, 2, 1, 1),
            new Node("dodge", 3, COOLDOWN, 1, 1, 2),
            new Node("telekinesis", 3, -1, 0, 1, 3),
            new Node("mana", 5, -1, 0, 2, 0),        // Alma
            new Node("regen", 3, MANA, 1, 2, 1)
    };

    private static String cachedLevels = null;
    private static int[] cachedThresholds = new int[0];

    private static int[] thresholds() {
        String raw = SansConfig.s("levels.xp");
        if (!raw.equals(cachedLevels)) {
            String[] parts = raw.split(",");
            int[] out = new int[parts.length];
            int n = 0;
            for (String p : parts) {
                try {
                    out[n++] = Integer.parseInt(p.trim());
                } catch (NumberFormatException e) {
                    // se ignora el valor mal escrito
                }
            }
            cachedThresholds = java.util.Arrays.copyOf(out, n);
            cachedLevels = raw;
        }
        return cachedThresholds;
    }

    public static int maxLevel() {
        return thresholds().length;
    }

    /** Nivel de una habilidad según su experiencia (usos). */
    public static int level(int xp) {
        int level = 0;
        for (int t : thresholds()) {
            if (xp >= t) level++;
        }
        return level;
    }

    public static int rank(PlayerState st, int node) {
        return st.nodes[node];
    }

    public static double damageMul(PlayerState st, Ability a) {
        return (1.0 + 0.06 * level(st.xp[a.ordinal()])) * (1.0 + 0.08 * rank(st, POWER));
    }

    public static double cooldownMul(PlayerState st, Ability a) {
        return Math.max(0.4, (1.0 - 0.03 * level(st.xp[a.ordinal()])) * (1.0 - 0.05 * rank(st, COOLDOWN)));
    }

    public static double dmg(PlayerState st, Ability a, double base) {
        return base * damageMul(st, a);
    }

    public static int maxMana(PlayerState st) {
        return (int) SansConfig.d("mana.base") + 20 * rank(st, MANA);
    }

    public static double manaRegen(PlayerState st) {
        return SansConfig.d("mana.regen_per_tick") * (1.0 + 0.25 * rank(st, REGEN));
    }

    public static int slots(PlayerState st) {
        return SansConfig.i("amulet.slots") + rank(st, SLOTS);
    }

    public static int maxFatigue(PlayerState st) {
        return SansConfig.i("dodge.max_fatigue") + 2 * rank(st, DODGE);
    }

    public static double krDamageMul(PlayerState st) {
        return 1.0 + 0.2 * rank(st, KR);
    }

    public static double krSeconds(PlayerState st) {
        return SansConfig.d("karma.kr_seconds") + 1.5 * rank(st, KR);
    }

    public static double holdSeconds(PlayerState st) {
        return SansConfig.d("telekinesis.hold_seconds") + 3.0 * rank(st, TELEKINESIS);
    }

    /** Suma un uso; al subir de nivel da un punto para el árbol. */
    public static void award(ServerPlayer p, net.minecraft.server.level.ServerLevel level, PlayerState st, Ability a) {
        int before = level(st.xp[a.ordinal()]);
        st.xp[a.ordinal()]++;
        int after = level(st.xp[a.ordinal()]);
        if (after > before) {
            st.points++;
            AbilityLogic.msg(p, Component.translatable("msg.sansmod.level_up",
                    Component.translatable("ability.sansmod." + a.id), after));
            AbilityLogic.sound(level, p.position(), SoundEvents.PLAYER_LEVELUP, 0.6f, 1.4f);
        }
    }

    /** Compra un rango del árbol si hay puntos y se cumple el requisito. */
    public static void buy(ServerPlayer p, PlayerState st, int node) {
        if (node < 0 || node >= NODES.length) return;
        Node n = NODES[node];
        if (st.nodes[node] >= n.max() || st.points < 1) return;
        if (n.requires() >= 0 && st.nodes[n.requires()] < n.requiredRank()) {
            AbilityLogic.msg(p, Component.translatable("msg.sansmod.node_locked"));
            return;
        }
        st.points--;
        st.nodes[node]++;
        long now = ((net.minecraft.server.level.ServerLevel) p.level()).getServer().getTickCount();
        AbilityLogic.sendSync(p, st, now);
        st.save(p, now);
    }
}
