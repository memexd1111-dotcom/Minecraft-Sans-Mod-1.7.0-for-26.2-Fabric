package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.SansConfig;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;

/** Datos reales de cada habilidad (leídos de la configuración) para las descripciones del menú. */
public final class AbilityInfo {
    private AbilityInfo() {}

    private static String f(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format("%.1f", v);
    }

    private static Component line(String key, String value) {
        return Component.translatable("info.sansmod." + key, value);
    }

    public static List<Component> lines(Ability a) {
        List<Component> out = new ArrayList<>();
        switch (a) {
            case DODGE -> {
                out.add(line("dodges", f(SansConfig.d("dodge.max_fatigue"))));
            }
            case KARMA -> {
                out.add(line("kr_damage", f(SansConfig.d("karma.kr_damage"))));
                out.add(line("kr_seconds", f(SansConfig.d("karma.kr_seconds"))));
            }
            case BONE -> {
                out.add(line("damage", f(SansConfig.d("bone.damage"))));
                out.add(line("count", f(SansConfig.d("bone.count")) + " (+" + f(SansConfig.d("bone.charge_extra")) + " por nivel de carga)"));
                out.add(line("range", f(SansConfig.d("bone.range"))));
            }
            case BLUE_BONE -> {
                out.add(line("damage", f(SansConfig.d("blue_bone.damage"))));
                out.add(line("count", f(SansConfig.d("bone.count"))));
                out.add(line("blue_rule", ""));
            }
            case ORANGE_BONE -> {
                out.add(line("damage", f(SansConfig.d("orange_bone.damage"))));
                out.add(line("count", f(SansConfig.d("bone.count"))));
                out.add(line("orange_rule", ""));
            }
            case BONE_WALL -> {
                out.add(line("damage", f(SansConfig.d("bone_wall.damage"))));
                out.add(line("width", f(SansConfig.d("bone_wall.width"))));
            }
            case BLASTER -> {
                out.add(line("damage", f(SansConfig.d("blaster.damage")) + " (hasta x"
                        + f(1.0 + SansConfig.d("blaster.charge_damage_bonus")) + " cargando)"));
                out.add(line("range", f(SansConfig.d("blaster.range"))));
            }
            case BLASTER_RAIN -> {
                out.add(line("damage", f(SansConfig.d("blaster_rain.damage")) + " por rayo, "
                        + f(SansConfig.d("blaster_rain.finisher_damage")) + " el pilar final"));
                out.add(line("count", f(SansConfig.d("blaster_rain.count"))));
                out.add(line("range", f(SansConfig.d("blaster_rain.range"))));
            }
            case TELEKINESIS -> {
                out.add(line("damage", f(SansConfig.d("telekinesis.slam_damage")) + " por choque"));
                out.add(line("range", f(SansConfig.d("telekinesis.range"))));
                out.add(line("duration", f(SansConfig.d("telekinesis.hold_seconds"))));
            }
            case TELEPORT -> {
                out.add(line("range", f(SansConfig.d("teleport.distance"))));
            }
            case EYE -> {
                out.add(line("duration", f(SansConfig.d("eye.duration_seconds"))));
                out.add(line("multiplier", f(SansConfig.d("eye.damage_multiplier"))));
            }
            case BAD_TIME -> {
                out.add(line("duration", f(SansConfig.d("bad_time.duration_seconds"))));
            }
        }
        if (!a.toggle) {
            out.add(line("cooldown", f(SansConfig.d("cooldown." + a.id))));
        }
        return out;
    }
}
