package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.SansMod;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class AbilityHud {
    public static final Identifier[] ICONS = new Identifier[Ability.ALL.length];

    static {
        for (Ability a : Ability.ALL) {
            ICONS[a.ordinal()] = SansMod.id("textures/gui/ability/" + a.id + ".png");
        }
    }

    private AbilityHud() {}

    /** Dibuja el icono de 32x32 escalado a size x size. */
    public static void icon(GuiGraphicsExtractor g, int index, int x, int y, int size) {
        g.blit(RenderPipelines.GUI_TEXTURED, ICONS[index], x, y, 0, 0, size, size, 32, 32, 32, 32);
        if (!ClientState.isUnlocked(index)) {
            g.fill(x, y, x + size, y + size, 0xC8101018); // bloqueada: hay que mejorar el amuleto
        }
    }

    /** Tecla asignada, en la esquina inferior derecha del icono. */
    public static void keyLabel(GuiGraphicsExtractor g, int index, int x, int y, int size) {
        String key = SansClient.keyLabel(index);
        if (key.isEmpty()) return;
        Font font = Minecraft.getInstance().font;
        Component label = Component.literal(key);
        g.text(font, label, x + size - font.width(label) - 1, y + size - 8, 0xFFFFEE88, true);
    }

    /** Oscurece el icono según el cooldown restante. */
    public static void cooldownOverlay(GuiGraphicsExtractor g, int index, int x, int y, int size) {
        int rem = ClientState.remaining[index];
        int tot = ClientState.total[index];
        if (ClientState.flash[index] > 0) { // ¡lista!: destello blanco que se apaga
            int a = Math.min(200, ClientState.flash[index] * 16);
            g.fill(x, y, x + size, y + size, (a << 24) | 0x00FFFFFF);
        }
        if (rem > 0 && tot > 0) {
            int h = Math.min(size, (int) Math.ceil(size * (rem / (double) tot)));
            g.fill(x, y, x + size, y + h, 0xB0000000);

            // segundos que faltan, centrados sobre el icono (enteros desde 10 s, con decimal debajo)
            String secs = rem >= 200 ? String.valueOf((rem + 19) / 20) : String.format("%.1f", rem / 20.0);
            Font font = Minecraft.getInstance().font;
            Component label = Component.literal(secs);
            g.text(font, label, x + (size - font.width(label)) / 2, y + (size - 8) / 2, 0xFFFFFFFF, true);
        }
    }

    public static void extract(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || !SansMod.hasCharm(player)) return;

        Font font = mc.font;
        int screenH = mc.getWindow().getGuiScaledHeight();
        int x = 8;
        int y = screenH - 70;
        int sel = ClientState.selected;
        Ability ability = Ability.ALL[sel];

        // tira con todas las habilidades (la elegida resaltada)
        for (int i = 0; i < Ability.ALL.length; i++) {
            int ix = x + i * 18;
            icon(g, i, ix, y - 21, 16);
            cooldownOverlay(g, i, ix, y - 21, 16);
            keyLabel(g, i, ix, y - 21, 16);
            if (i == sel) g.outline(ix - 1, y - 22, 18, 18, 0xFFFFFF55);
        }

        // panel de la habilidad elegida
        g.fill(x - 4, y - 2, x + 190, y + 58, 0x90000000);
        icon(g, sel, x, y, 32);
        cooldownOverlay(g, sel, x, y, 32);
        keyLabel(g, sel, x, y, 32);

        Component name = Component.translatable("ability.sansmod." + ability.id);
        g.text(font, name, x + 38, y + 3, 0xFFFFFFFF, true);

        Component status;
        int color = 0xFF55FF55;
        if (ability.toggle) {
            boolean on = ability == Ability.DODGE ? ClientState.dodgeOn : ClientState.karmaOn;
            status = Component.translatable(on ? "hud.sansmod.on" : "hud.sansmod.off");
            color = on ? 0xFF55FF55 : 0xFFAAAAAA;
        } else if (ClientState.remaining[sel] > 0) {
            status = Component.literal(String.format("%.1f s", ClientState.remaining[sel] / 20.0));
            color = 0xFFFF5555;
        } else {
            status = Component.translatable("hud.sansmod.ready");
        }
        g.text(font, status, x + 38, y + 16, color, true);

        // energía de esquive
        int barX = x;
        int barY = y + 36;
        int barW = 100;
        g.text(font, Component.translatable("hud.sansmod.energy"), barX, barY - 1, 0xFFAAAAAA, false);
        g.fill(barX, barY + 9, barX + barW, barY + 13, 0xFF202020);
        int filled = (int) (barW * (1.0 - ClientState.fatigue / (double) ClientState.maxFatigue));
        g.fill(barX, barY + 9, barX + Math.max(0, filled), barY + 13, 0xFF55CCFF);

        // magia (MP)
        if (com.benja.sansmod.SansConfig.s("resource_mode").equalsIgnoreCase("mana")) {
            double mf = Math.min(1.0, ClientState.mana / (double) ClientState.maxMana);
            g.fill(barX, barY + 16, barX + barW, barY + 20, 0xFF202020);
            g.fill(barX, barY + 16, barX + (int) (barW * mf), barY + 20, 0xFFB366FF);
            g.text(font, Component.literal(ClientState.mana + "/" + ClientState.maxMana), barX + barW + 4, barY + 13, 0xFFCC99FF, false);
        }
        if (ClientState.points > 0) {
            g.text(font, Component.translatable("hud.sansmod.points", ClientState.points), x, y - 34, 0xFFFFDD55, true);
        }

        // estados temporales
        int ty = y + 16;
        if (ClientState.serious > 0) {
            g.text(font, Component.translatable("hud.sansmod.eye",
                    String.format("%.0f", ClientState.serious / 20.0)), x + 90, ty, 0xFF55FFFF, true);
        }
        if (ClientState.badTime > 0) {
            g.text(font, Component.translatable("hud.sansmod.bad_time",
                    String.format("%.0f", ClientState.badTime / 20.0)), x + 90, ty + 10, 0xFFFF77FF, true);
        }
        // telequinesis: segundos que quedan sujetando al objetivo
        int screenW = mc.getWindow().getGuiScaledWidth();
        if (ClientState.telekinesis > 0) {
            Component tk = Component.translatable("hud.sansmod.telekinesis",
                    String.format("%.1f", ClientState.telekinesis / 20.0));
            g.text(font, tk, (screenW - font.width(tk)) / 2, screenH / 2 + 22, 0xFF66CCFF, true);
            Component hint = Component.translatable("hud.sansmod.telekinesis_hint");
            g.text(font, hint, (screenW - font.width(hint)) / 2, screenH / 2 + 33, 0xFFAAAAAA, true);
        }

        // barra de carga (huesos y blaster) bajo la mira
        if (ClientState.chargeIndex >= 0 && ClientState.chargeTicks > 3) {
            int max = Math.max(1, com.benja.sansmod.SansConfig.i("charge.max_ticks"));
            int bw = 62;
            int bx = (screenW - bw) / 2;
            int by = screenH / 2 + 12;
            double frac = Math.min(1.0, ClientState.chargeTicks / (double) max);
            g.fill(bx - 1, by - 1, bx + bw + 1, by + 5, 0xA0000000);
            g.fill(bx, by, bx + (int) (bw * frac), by + 4, frac >= 1.0 ? 0xFFFFFFFF : 0xFF55DDFF);
        }

        if (ClientState.karmaOn && ability != Ability.KARMA) {
            g.text(font, Component.translatable("ability.sansmod.karma"), x + 140, y + 3, 0xFFFF77FF, true);
        }
    }
}
