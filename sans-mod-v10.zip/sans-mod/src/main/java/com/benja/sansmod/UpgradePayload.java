package com.benja.sansmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Cliente -> servidor: comprar un rango del árbol de mejoras. */
public record UpgradePayload(int node) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<UpgradePayload> TYPE =
            new CustomPacketPayload.Type<>(SansMod.id("upgrade"));

    public static final StreamCodec<RegistryFriendlyByteBuf, UpgradePayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, UpgradePayload::node,
            UpgradePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
