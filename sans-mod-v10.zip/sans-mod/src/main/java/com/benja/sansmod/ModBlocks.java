package com.benja.sansmod;

import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.references.BlockItemId;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
    private static final BlockItemId SANS_TABLE_ID = BlockItemId.create(SansMod.id("sans_table"), SansMod.id("sans_table"));

    /** Donde se inscriben las habilidades en el amuleto. */
    public static final Block SANS_TABLE = register(SANS_TABLE_ID, SansTableBlock::new,
            BlockBehaviour.Properties.of().strength(2.5f).sound(SoundType.BONE_BLOCK).noOcclusion());

    private ModBlocks() {}

    private static Block register(BlockItemId id, Function<BlockBehaviour.Properties, Block> factory,
                                  BlockBehaviour.Properties properties) {
        ResourceKey<Block> blockKey = id.block();
        Block block = factory.apply(properties.setId(blockKey));
        Registry.register(BuiltInRegistries.BLOCK, blockKey, block);
        BlockItem item = new BlockItem(block, new Item.Properties().useBlockDescriptionPrefix().setId(id.item()));
        Registry.register(BuiltInRegistries.ITEM, id.item(), item);
        return block;
    }

    /** Fuerza el registro de los bloques (antes que los objetos, porque el item del bloque va en la pestaña). */
    public static void initialize() {}
}
