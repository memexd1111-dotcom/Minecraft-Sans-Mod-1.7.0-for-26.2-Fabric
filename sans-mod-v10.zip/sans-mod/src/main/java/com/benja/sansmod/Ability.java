package com.benja.sansmod;

/** Lista de habilidades. El orden es el que se ve en el menú y viaja por red como número. */
public enum Ability {
    DODGE("dodge", true, false, true),
    KARMA("karma", true, false, false),
    BONE("bone", false, true, true),
    BONE_WALL("bone_wall", false, false, false),
    BLASTER("blaster", false, true, false),
    BLASTER_RAIN("blaster_rain", false, false, false),
    TELEKINESIS("telekinesis", false, false, false),
    TELEPORT("teleport", false, false, true),
    EYE("eye", false, false, false),
    BAD_TIME("bad_time", false, false, false),
    BLUE_BONE("blue_bone", false, true, false),
    ORANGE_BONE("orange_bone", false, true, false);

    public static final Ability[] ALL = values();

    public final String id;
    /** true = se activa/desactiva (esquive, karma); false = se lanza. */
    public final boolean toggle;
    /** true = se puede cargar manteniendo la tecla. */
    public final boolean charges;
    /** true = viene con el amuleto; si no, hay que inscribirla con su objeto en la Mesa de Sans. */
    public final boolean free;

    Ability(String id, boolean toggle, boolean charges, boolean free) {
        this.id = id;
        this.toggle = toggle;
        this.charges = charges;
        this.free = free;
    }

    /** Cooldown base, leído de la configuración (cooldown.<id>, en segundos). */
    public int cooldownTicks() {
        return (int) Math.round(SansConfig.d("cooldown." + id) * 20.0);
    }
}
