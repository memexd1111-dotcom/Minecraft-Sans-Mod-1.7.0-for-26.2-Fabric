package com.benja.sansmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Servidor -> cliente: cooldowns, energía de esquive y estados, para el HUD. */
public record SyncPayload(int[] remaining, int[] total, int fatigue, int maxFatigue,
                          boolean dodgeOn, boolean karmaOn, int serious, int badTime,
                          int telekinesis, int unlocked, int mana, int maxMana, int slots, int loadout,
                          int points, int[] xp, int[] nodes)
        implements CustomPacketPayload {

    public static final CustomPacketPayload.Type<SyncPayload> TYPE =
            new CustomPacketPayload.Type<>(SansMod.id("sync"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SyncPayload> CODEC =
            StreamCodec.ofMember(SyncPayload::write, SyncPayload::read);

    public void write(RegistryFriendlyByteBuf buf) {
        buf.writeVarInt(remaining.length);
        for (int i = 0; i < remaining.length; i++) {
            buf.writeVarInt(remaining[i]);
            buf.writeVarInt(total[i]);
        }
        buf.writeVarInt(fatigue);
        buf.writeVarInt(maxFatigue);
        buf.writeBoolean(dodgeOn);
        buf.writeBoolean(karmaOn);
        buf.writeVarInt(serious);
        buf.writeVarInt(badTime);
        buf.writeVarInt(telekinesis);
        buf.writeVarInt(unlocked);
        buf.writeVarInt(mana);
        buf.writeVarInt(maxMana);
        buf.writeVarInt(slots);
        buf.writeVarInt(loadout);
        buf.writeVarInt(points);
        buf.writeVarInt(xp.length);
        for (int v : xp) buf.writeVarInt(v);
        buf.writeVarInt(nodes.length);
        for (int v : nodes) buf.writeVarInt(v);
    }

    public static SyncPayload read(RegistryFriendlyByteBuf buf) {
        int n = buf.readVarInt();
        int[] remaining = new int[n];
        int[] total = new int[n];
        for (int i = 0; i < n; i++) {
            remaining[i] = buf.readVarInt();
            total[i] = buf.readVarInt();
        }
        int fatigue = buf.readVarInt();
        int maxFatigue = buf.readVarInt();
        boolean dodgeOn = buf.readBoolean();
        boolean karmaOn = buf.readBoolean();
        int serious = buf.readVarInt();
        int badTime = buf.readVarInt();
        int telekinesis = buf.readVarInt();
        int unlocked = buf.readVarInt();
        int mana = buf.readVarInt();
        int maxMana = buf.readVarInt();
        int slots = buf.readVarInt();
        int loadout = buf.readVarInt();
        int points = buf.readVarInt();
        int[] xp = new int[buf.readVarInt()];
        for (int i = 0; i < xp.length; i++) xp[i] = buf.readVarInt();
        int[] nodes = new int[buf.readVarInt()];
        for (int i = 0; i < nodes.length; i++) nodes[i] = buf.readVarInt();
        return new SyncPayload(remaining, total, fatigue, maxFatigue, dodgeOn, karmaOn, serious, badTime,
                telekinesis, unlocked, mana, maxMana, slots, loadout, points, xp, nodes);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
