package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.CastPayload;
import com.benja.sansmod.SansConfig;
import com.benja.sansmod.SansMod;
import com.benja.sansmod.ShakePayload;
import com.benja.sansmod.SyncPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import java.lang.reflect.Field;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

public class SansClient implements ClientModInitializer {
    private static KeyMapping castKey;
    private static KeyMapping menuKey;
    private static KeyMapping nextKey;
    private static KeyMapping prevKey;
    private static KeyMapping treeKey;

    /** Una tecla propia por habilidad, en el orden del enum Ability (se cambian en Controles). */
    private static final int[] ABILITY_DEFAULT_KEYS = {
            InputConstants.KEY_O, // DODGE (esquive: activar/desactivar)
            InputConstants.KEY_K, // KARMA (activar/desactivar)
            InputConstants.KEY_B, // BONE (huesos)
            InputConstants.KEY_N, // BONE_WALL (muro de huesos)
            InputConstants.KEY_G, // BLASTER (Gaster)
            InputConstants.KEY_H, // BLASTER_RAIN (lluvia de blasters)
            InputConstants.KEY_Y, // TELEKINESIS (agarrar / lanzar)
            InputConstants.KEY_J, // TELEPORT (atajo)
            InputConstants.KEY_U, // EYE (ojo brillante)
            InputConstants.KEY_I, // BAD_TIME (mal momento)
            InputConstants.KEY_M, // BLUE_BONE (hueso azul, mejora del amuleto)
            InputConstants.KEY_COMMA // ORANGE_BONE (hueso naranja, mejora del amuleto)
    };
    private static final KeyMapping[] abilityKeys = new KeyMapping[Ability.ALL.length];
    private static final String[] keyLabels = new String[Ability.ALL.length];

    private static int clientTicks = 0;
    private static float lastShakeX = 0;
    private static float lastShakeY = 0;
    private static Field screenField;
    private static boolean screenFieldTried = false;

    /** Nombre corto de la tecla de una habilidad (para mostrarlo sobre el icono). */
    public static String keyLabel(int index) {
        String s = keyLabels[index];
        return s == null ? "" : s;
    }

    private static void refreshLabels() {
        for (int i = 0; i < abilityKeys.length; i++) {
            try {
                String name = ((Component) KeyMapping.class.getMethod("getTranslatedKeyMessage")
                        .invoke(abilityKeys[i])).getString();
                keyLabels[i] = name.length() > 3 ? name.substring(0, 3) : name;
            } catch (ReflectiveOperationException | RuntimeException e) {
                keyLabels[i] = "";
            }
        }
    }

    /** true si hay una pantalla abierta (inventario, menú...). Se lee por reflexión para no depender del nombre. */
    private static boolean screenOpen(Minecraft client) {
        if (!screenFieldTried) {
            screenFieldTried = true;
            try {
                screenField = Minecraft.class.getField("screen");
            } catch (ReflectiveOperationException e) {
                screenField = null;
            }
        }
        try {
            return screenField != null && screenField.get(client) != null;
        } catch (ReflectiveOperationException e) {
            return false;
        }
    }

    private static void sendCast(int index, int charge) {
        ClientPlayNetworking.send(new CastPayload(index, charge));
    }

    /**
     * Carga: mientras mantienes la tecla de una habilidad cargable sube la carga (con un tono que sube);
     * al soltarla se lanza con esa carga. Un toque rápido lanza sin carga.
     */
    private static void chargeStep(Minecraft client, int index, boolean down) {
        int max = Math.max(1, SansConfig.i("charge.max_ticks"));
        if (down && (ClientState.chargeIndex == -1 || ClientState.chargeIndex == index)) {
            ClientState.chargeIndex = index;
            if (ClientState.chargeTicks < max) ClientState.chargeTicks++;
            if (ClientState.chargeTicks > 3 && ClientState.chargeTicks % 4 == 0) {
                float frac = ClientState.chargeTicks / (float) max;
                client.player.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.5f, 0.6f + 1.4f * frac);
            }
        } else if (!down && ClientState.chargeIndex == index) {
            int t = ClientState.chargeTicks;
            ClientState.chargeIndex = -1;
            ClientState.chargeTicks = 0;
            sendCast(index, t > 3 ? t : 0);
        }
    }

    private static void applyShake(LocalPlayer pl) {
        pl.setXRot(pl.getXRot() - lastShakeX);
        pl.setYRot(pl.getYRot() - lastShakeY);
        lastShakeX = 0;
        lastShakeY = 0;
        if (ClientState.shakeTicks > 0) {
            ClientState.shakeTicks--;
            if (ClientState.cameraShake) {
                float amp = ClientState.shakeAmp * ClientState.shakeTicks / (float) Math.max(1, ClientState.shakeTotal);
                ThreadLocalRandom r = ThreadLocalRandom.current();
                lastShakeX = (r.nextFloat() - 0.5f) * 2.0f * amp;
                lastShakeY = (r.nextFloat() - 0.5f) * 2.0f * amp;
                pl.setXRot(pl.getXRot() + lastShakeX);
                pl.setYRot(pl.getYRot() + lastShakeY);
            }
        }
    }

    @Override
    public void onInitializeClient() {
        ClientState.loadSelected();
        KeyMapping.Category category = KeyMapping.Category.register(SansMod.id("main"));

        castKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sansmod.cast", InputConstants.Type.KEYSYM, InputConstants.KEY_R, category));
        menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sansmod.menu", InputConstants.Type.KEYSYM, InputConstants.KEY_V, category));
        nextKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sansmod.next", InputConstants.Type.KEYSYM, InputConstants.KEY_X, category));
        prevKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sansmod.prev", InputConstants.Type.KEYSYM, InputConstants.KEY_Z, category));

        treeKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.sansmod.tree", InputConstants.Type.KEYSYM, InputConstants.KEY_PERIOD, category));

        for (Ability a : Ability.ALL) {
            abilityKeys[a.ordinal()] = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                    "key.sansmod.ability." + a.id, InputConstants.Type.KEYSYM,
                    ABILITY_DEFAULT_KEYS[a.ordinal()], category));
        }

        // Los nombres de las teclas se piden a GLFW, que aún no está iniciado aquí: se leen en el primer tick dentro del mundo.
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.TYPE,
                (payload, context) -> ClientState.apply(payload));
        ClientPlayNetworking.registerGlobalReceiver(com.benja.sansmod.OpenTablePayload.TYPE,
                (payload, context) -> Minecraft.getInstance().setScreenAndShow(new TableScreen()));
        ClientPlayNetworking.registerGlobalReceiver(ShakePayload.TYPE,
                (payload, context) -> ClientState.shake(payload.intensity(), payload.ticks()));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientState.tick();
            if (client.player == null) return;
            if (clientTicks++ % 20 == 0) refreshLabels();
            applyShake(client.player);

            // con una pantalla abierta (inventario, menú...) se cancela cualquier carga sin lanzar
            if (screenOpen(client)) {
                ClientState.chargeIndex = -1;
                ClientState.chargeTicks = 0;
                while (castKey.consumeClick()) { }
                for (KeyMapping k : abilityKeys) while (k.consumeClick()) { }
            } else {
                // R lanza la habilidad elegida; además cada habilidad tiene su tecla propia.
                // Las cargables (huesos, blaster) se cargan mientras mantienes la tecla.
                for (int i = 0; i < abilityKeys.length; i++) {
                    boolean viaCast = i == ClientState.selected;
                    if (Ability.ALL[i].charges) {
                        boolean clicked = false;
                        while (abilityKeys[i].consumeClick()) clicked = true;
                        if (viaCast) while (castKey.consumeClick()) clicked = true;
                        boolean down = abilityKeys[i].isDown() || (viaCast && castKey.isDown());
                        if (clicked && !down && ClientState.chargeIndex != i) {
                            sendCast(i, 0); // toque tan rápido que la tecla ya subió: lanzar sin carga
                        } else {
                            chargeStep(client, i, down);
                        }
                    } else {
                        while (abilityKeys[i].consumeClick()) sendCast(i, 0);
                        if (viaCast) while (castKey.consumeClick()) sendCast(i, 0);
                    }
                }
            }
            while (menuKey.consumeClick()) {
                client.setScreenAndShow(new AbilityScreen());
            }
            while (treeKey.consumeClick()) {
                client.setScreenAndShow(new TreeScreen());
            }
            while (nextKey.consumeClick()) {
                ClientState.cycle(1);
            }
            while (prevKey.consumeClick()) {
                ClientState.cycle(-1);
            }
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, SansMod.id("hud"), AbilityHud::extract);
    }
}
