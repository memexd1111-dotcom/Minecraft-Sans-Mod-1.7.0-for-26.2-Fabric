package com.benja.sansmod;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Objetos de habilidad que sueltan los mobs al morir a manos de un jugador: los esqueletos sueltan hueso
 * azul y naranja, y las variantes del Nether y el End sueltan los demás.
 */
public final class BoneDrops {
    private BoneDrops() {}

    public static void onDeath(LivingEntity entity, DamageSource source) {
        if (!(entity.level() instanceof ServerLevel level)) return;
        if (!(source.getEntity() instanceof ServerPlayer)) return;

        SansMobs.Variant v = SansMobs.variantOf(entity);
        if (v != null) {
            switch (v) {
                case KARMA_SKELETON -> {
                    drop(level, entity, ModItems.KARMA_ESSENCE, 0.60);
                    drop(level, entity, ModItems.ANCIENT_RIB, 0.40);
                }
                case CLOCK_SPECTER -> {
                    drop(level, entity, ModItems.BROKEN_CLOCK, 0.50);
                    drop(level, entity, ModItems.BURNING_EYE, 0.30);
                }
                case TELEKINETIC_ENDERMAN -> drop(level, entity, ModItems.TELEKINETIC_PEARL, 0.55);
                case GASTER_WATCHER -> {
                    drop(level, entity, ModItems.GASTER_SHARD, 0.55);
                    drop(level, entity, ModItems.GASTER_CROWN, 0.20);
                }
                case SANS_SKELETON -> {
                    drop(level, entity, ModItems.BLUE_BONE, 0.45);
                    drop(level, entity, ModItems.ORANGE_BONE, 0.45);
                }
            }
            return;
        }
        if (entity.getType() == EntityTypes.SKELETON || entity.getType() == EntityTypes.STRAY
                || entity.getType() == EntityTypes.BOGGED) {
            drop(level, entity, ModItems.BLUE_BONE, SansConfig.d("drops.blue_bone_chance") / SansConfig.d("mobs.drop_scale"));
            drop(level, entity, ModItems.ORANGE_BONE, SansConfig.d("drops.orange_bone_chance") / SansConfig.d("mobs.drop_scale"));
        }
    }

    /** chance es la probabilidad base; mobs.drop_scale la multiplica (para hacerlos más o menos comunes). */
    private static void drop(ServerLevel level, LivingEntity entity, Item item, double chance) {
        double scaled = Math.min(1.0, chance * SansConfig.d("mobs.drop_scale"));
        if (entity.getRandom().nextDouble() >= scaled) return;
        level.addFreshEntity(new ItemEntity(level, entity.getX(), entity.getY() + 0.5, entity.getZ(), new ItemStack(item)));
    }
}
