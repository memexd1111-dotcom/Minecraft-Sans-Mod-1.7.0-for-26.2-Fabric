package com.benja.sansmod;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Objetos que desbloquean habilidades: se inscriben en el amuleto con la Mesa de Sans. */
public final class AbilityItems {
    private AbilityItems() {}

    /** Objeto que corresponde a una habilidad (null si la habilidad viene con el amuleto). */
    public static Item itemFor(Ability a) {
        return switch (a) {
            case KARMA -> ModItems.KARMA_ESSENCE;
            case BONE_WALL -> ModItems.ANCIENT_RIB;
            case BLASTER -> ModItems.GASTER_SHARD;
            case BLASTER_RAIN -> ModItems.GASTER_CROWN;
            case TELEKINESIS -> ModItems.TELEKINETIC_PEARL;
            case EYE -> ModItems.BURNING_EYE;
            case BAD_TIME -> ModItems.BROKEN_CLOCK;
            case BLUE_BONE -> ModItems.BLUE_BONE;
            case ORANGE_BONE -> ModItems.ORANGE_BONE;
            default -> null;
        };
    }

    /** Habilidad que desbloquea un objeto (null si no es un objeto de habilidad). */
    public static Ability abilityOf(ItemStack stack) {
        for (Ability a : Ability.ALL) {
            Item item = itemFor(a);
            if (item != null && stack.is(item)) return a;
        }
        return null;
    }
}
