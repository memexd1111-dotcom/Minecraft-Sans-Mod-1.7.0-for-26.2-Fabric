package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Menú radial: las habilidades forman una rueda alrededor de la mira. Haz clic en una para elegirla;
 * abajo se ven sus datos reales (daño, alcance, cooldown...) y la tecla asignada.
 */
public class AbilityScreen extends Screen {
    private static final int BTN = 36;

    private int cx;
    private int cy;
    private int ring;

    public AbilityScreen() {
        super(Component.translatable("screen.sansmod.title"));
    }

    private int buttonX(int i) {
        double ang = -Math.PI / 2.0 + i * 2.0 * Math.PI / Ability.ALL.length;
        return cx + (int) Math.round(Math.cos(ang) * ring) - BTN / 2;
    }

    private int buttonY(int i) {
        double ang = -Math.PI / 2.0 + i * 2.0 * Math.PI / Ability.ALL.length;
        return cy + (int) Math.round(Math.sin(ang) * ring) - BTN / 2;
    }

    @Override
    protected void init() {
        cx = this.width / 2;
        cy = this.height / 2 - 18;
        ring = Math.max(50, Math.min(84, Math.min(this.width, this.height) / 2 - 78));

        addRenderableWidget(Button.builder(Component.translatable("screen.sansmod.tree"),
                b -> net.minecraft.client.Minecraft.getInstance().setScreenAndShow(new TreeScreen()))
                .bounds(this.width - 132, this.height - 30, 120, 20).build());

        for (int i = 0; i < Ability.ALL.length; i++) {
            final int index = i;
            addRenderableWidget(Button.builder(Component.empty(), b -> {
                if (!ClientState.isUnlocked(index)) return; // bloqueada: falta la mejora del amuleto
                ClientState.selected = index;
                ClientState.saveSelected();
                this.onClose();
            }).bounds(buttonX(i), buttonY(i), BTN, BTN).build());
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        g.text(this.font, this.title, (this.width - this.font.width(this.title)) / 2, 12, 0xFFFFFFFF, true);

        // anillo decorativo de puntos
        for (int k = 0; k < 96; k++) {
            double a = k * 2.0 * Math.PI / 96.0;
            int dx = cx + (int) Math.round(Math.cos(a) * (ring + 2));
            int dy = cy + (int) Math.round(Math.sin(a) * (ring + 2));
            g.fill(dx, dy, dx + 1, dy + 1, 0x66AACCFF);
        }

        int hovered = -1;
        for (int i = 0; i < Ability.ALL.length; i++) {
            int bx = buttonX(i);
            int by = buttonY(i);
            AbilityHud.icon(g, i, bx + 2, by + 2, 32);
            AbilityHud.cooldownOverlay(g, i, bx + 2, by + 2, 32);
            AbilityHud.keyLabel(g, i, bx + 2, by + 2, 32);
            if (i == ClientState.selected) g.outline(bx - 1, by - 1, BTN + 2, BTN + 2, 0xFFFFFF55);
            if (mouseX >= bx && mouseX < bx + BTN && mouseY >= by && mouseY < by + BTN) hovered = i;
        }

        int shown = hovered >= 0 ? hovered : ClientState.selected;
        Ability a = Ability.ALL[shown];
        Component name = Component.translatable("ability.sansmod." + a.id);
        g.text(this.font, name, cx - this.font.width(name) / 2, cy - 8, 0xFFFFFF55, true);

        boolean locked = !ClientState.isUnlocked(shown);
        Component sub = locked ? Component.translatable("screen.sansmod.locked")
                : Component.translatable(ClientState.remaining[shown] > 0 ? "screen.sansmod.recharging" : "hud.sansmod.ready");
        g.text(this.font, sub, cx - this.font.width(sub) / 2, cy + 4, locked ? 0xFFFF7777 : 0xFFAAAAAA, false);

        // descripción y datos reales debajo de la rueda
        int y = cy + ring + BTN / 2 + 12;
        Component desc = Component.translatable("ability.sansmod." + a.id + ".desc");
        g.text(this.font, desc, (this.width - this.font.width(desc)) / 2, y, 0xFFCCCCCC, false);
        y += 13;
        List<Component> info = AbilityInfo.lines(a);
        for (Component line : info) {
            g.text(this.font, line, (this.width - this.font.width(line)) / 2, y, 0xFF99DDFF, false);
            y += 10;
        }
        Component note = Component.translatable("screen.sansmod.config_note");
        g.text(this.font, note, (this.width - this.font.width(note)) / 2, this.height - 14, 0xFF777777, false);
    }
}
