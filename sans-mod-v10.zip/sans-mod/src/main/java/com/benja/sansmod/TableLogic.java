package com.benja.sansmod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Lógica de la Mesa de Sans: inscribir habilidades en el amuleto y volver a quitarlas. */
public final class TableLogic {
    private TableLogic() {}

    public static void open(ServerPlayer p) {
        ServerLevel level = (ServerLevel) p.level();
        long now = level.getServer().getTickCount();
        if (!SansMod.hasCharm(p)) {
            AbilityLogic.msg(p, Component.translatable("msg.sansmod.table_need_charm"));
            return;
        }
        PlayerState st = PlayerState.of(p);
        st.tableUntil = now + 1200; // 1 minuto para operar tras abrir la mesa
        AbilityLogic.sendSync(p, st, now);
        ServerPlayNetworking.send(p, new OpenTablePayload());
    }

    public static void handle(ServerPlayer p, boolean insert, int index) {
        if (index < 0 || index >= Ability.ALL.length) return;
        Ability a = Ability.ALL[index];
        if (a.free) return;
        ServerLevel level = (ServerLevel) p.level();
        long now = level.getServer().getTickCount();
        PlayerState st = PlayerState.of(p);
        if (now > st.tableUntil || !SansMod.hasCharm(p)) return;

        Item item = AbilityItems.itemFor(a);
        int bit = 1 << index;
        if (insert) {
            if ((st.loadout & bit) != 0) return;
            if (st.slotsUsed() >= Progression.slots(st)) {
                AbilityLogic.msg(p, Component.translatable("msg.sansmod.no_slots"));
                return;
            }
            Inventory inv = p.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (s.is(item)) {
                    s.shrink(1);
                    st.loadout |= bit;
                    AbilityLogic.sound(level, p.position(), net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE, 1.0f, 1.2f);
                    AbilityLogic.msg(p, Component.translatable("msg.sansmod.inscribed", Component.translatable("ability.sansmod." + a.id)));
                    break;
                }
            }
        } else {
            if ((st.loadout & bit) == 0) return;
            st.loadout &= ~bit;
            ItemStack back = new ItemStack(item);
            if (!p.getInventory().add(back)) {
                level.addFreshEntity(new ItemEntity(level, p.getX(), p.getY() + 0.5, p.getZ(), back));
            }
            AbilityLogic.sound(level, p.position(), net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE, 1.0f, 0.8f);
            AbilityLogic.msg(p, Component.translatable("msg.sansmod.removed", Component.translatable("ability.sansmod." + a.id)));
        }
        AbilityLogic.sendSync(p, st, now);
        st.save(p, now);
    }
}
