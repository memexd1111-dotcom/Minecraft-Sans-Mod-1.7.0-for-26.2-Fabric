package com.benja.sansmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Servidor -> cliente: abrir la pantalla de la Mesa de Sans. */
public record OpenTablePayload() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<OpenTablePayload> TYPE =
            new CustomPacketPayload.Type<>(SansMod.id("open_table"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenTablePayload> CODEC =
            StreamCodec.unit(new OpenTablePayload());

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
