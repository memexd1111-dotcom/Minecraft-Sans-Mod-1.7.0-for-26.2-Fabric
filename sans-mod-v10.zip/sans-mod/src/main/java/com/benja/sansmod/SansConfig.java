package com.benja.sansmod;

import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

/** Configuración en config/sansmod.properties (se crea sola con los valores por defecto). */
public final class SansConfig {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    private static final Properties PROPS = new Properties();

    private static final String HEADER = """
            # Sans Abilities - configuración
            # Tiempos en segundos salvo que diga "ticks" (20 ticks = 1 segundo).
            # Borra una línea para volver a su valor por defecto.
            """;

    /** Súbela cuando cambien los valores por defecto de cooldowns/hambre: se migran los archivos viejos. */
    private static final int CONFIG_VERSION = 2;

    static {
        def("config_version", String.valueOf(CONFIG_VERSION));
        def("require_item", "true");          // si es false, cualquiera puede usar las habilidades sin el amuleto
        def("exhaustion_per_cast", "1.0");    // hambre que cuesta lanzar una habilidad (balance de supervivencia)

        def("cooldown.dodge", "1");
        def("cooldown.karma", "1");
        def("cooldown.bone", "1.5");
        def("cooldown.bone_wall", "6");
        def("cooldown.blaster", "8");
        def("cooldown.blaster_rain", "20");
        def("cooldown.telekinesis", "6");        // empieza al soltar al objetivo
        def("cooldown.teleport", "3");
        def("cooldown.eye", "30");
        def("cooldown.bad_time", "35");

        def("bone.count", "3");
        def("bone.damage", "4.0");
        def("bone.range", "32");
        def("bone.speed", "2.0");
        def("bone.spread_degrees", "8");

        def("bone_wall.damage", "6.0");
        def("bone_wall.width", "7");
        def("bone_wall.distance", "3");
        def("bone_wall.rise_ticks", "8");

        def("blaster.damage", "14.0");
        def("blaster.range", "48");
        def("blaster.charge_ticks", "25");
        def("blaster.beam_radius", "1.0");

        def("blaster_rain.count", "6");
        def("blaster_rain.damage", "9.0");
        def("blaster_rain.radius", "6");
        def("blaster_rain.range", "40");

        def("cooldown.blue_bone", "3");
        def("cooldown.orange_bone", "3");
        def("blue_bone.damage", "6.0");               // solo daña si el objetivo se mueve
        def("orange_bone.damage", "6.0");             // solo daña si el objetivo está quieto
        def("charge.max_ticks", "40");                // ticks máximos manteniendo la tecla (huesos y blaster)
        def("bone.charge_extra", "2");                // huesos extra por cada nivel de carga (hasta 3 niveles)
        def("blaster.charge_damage_bonus", "1.0");    // +100% de daño con la carga completa
        def("blaster.charge_radius_bonus", "0.6");    // +60% de grosor con la carga completa
        def("blaster_rain.spread", "3.5");            // radio donde caen los rayos alrededor del objetivo
        def("blaster_rain.warning_ticks", "16");      // aviso en el suelo antes de cada rayo
        def("blaster_rain.finisher_damage", "12.0");  // pilar final sobre el objetivo
        def("karma.kr_seconds", "4");                 // duración del KR (se renueva con cada golpe)
        def("karma.kr_interval_ticks", "10");         // cada cuántos ticks hace daño
        def("karma.kr_damage", "0.5");                // daño por pulso y por acumulación
        def("karma.kr_max_stacks", "5");
        def("telekinesis.min_distance", "2.5");       // distancia mínima al acercar (agachado)
        def("telekinesis.adjust_speed", "0.18");      // bloques por tick al acercar/alejar
        def("drops.blue_bone_chance", "0.12");        // probabilidad por esqueleto muerto por un jugador
        def("drops.orange_bone_chance", "0.12");
        def("unlock_all", "false");                   // true = todas las habilidades sin inscribirlas (pruebas)
        def("amulet.slots", "3");                     // habilidades extra que caben en el amuleto (+ las del árbol)
        def("levels.xp", "10,30,70,140,250");         // usos que hacen falta para cada nivel de una habilidad
        def("resource_mode", "mana");                 // mana = cuesta magia (MP); hunger = cuesta hambre
        def("mana.base", "100");
        def("mana.regen_per_tick", "0.25");
        def("mana.cost.bone", "8");
        def("mana.cost.bone_wall", "20");
        def("mana.cost.blaster", "25");
        def("mana.cost.blaster_rain", "45");
        def("mana.cost.telekinesis", "20");
        def("mana.cost.teleport", "12");
        def("mana.cost.eye", "30");
        def("mana.cost.bad_time", "35");
        def("mana.cost.blue_bone", "10");
        def("mana.cost.orange_bone", "10");
        def("protect.pets", "true");                  // no dañar mascotas domadas
        def("protect.villagers", "true");             // no dañar aldeanos ni comerciantes
        def("protect.teams", "true");                 // no dañar a quien esté en tu equipo
        def("particles.quality", "high");             // high, medium o low (menos partículas para PC modestas)
        def("mobs.enabled", "true");                  // variantes de mobs del Nether y el End
        def("mobs.variant_chance", "0.15");           // probabilidad de que un mob sea una variante
        def("mobs.sans_skeleton_chance", "0.12");     // esqueletos que atacan con huesos azules/naranjas
        def("mobs.attack_interval_ticks", "140");
        def("mobs.attack_damage", "4.0");
        def("mobs.drop_scale", "1.0");                // multiplica la probabilidad de los objetos de habilidad
        def("telekinesis.range", "24");
        def("telekinesis.hold_seconds", "10");        // cuánto puedes mantener agarrado al objetivo
        def("telekinesis.max_speed", "1.6");          // velocidad máxima (bloques por tick) al moverlo con la mirada
        def("telekinesis.throw_speed", "2.2");        // velocidad al lanzarlo con el segundo uso
        def("telekinesis.min_impact_speed", "0.7");   // velocidad mínima para que un choque cuente como golpe
        def("telekinesis.slam_damage", "8.0");        // daño de un choque a ~1.2 bloques/tick (escala con la velocidad)

        def("teleport.distance", "12");

        def("dodge.max_fatigue", "8");        // esquives seguidos antes de cansarte
        def("dodge.recovery_seconds", "3");   // segundos para recuperar 1 de energía
        def("dodge.window_ticks", "8");       // ticks de "invulnerabilidad" tras esquivar

        def("karma.wither_seconds", "5");

        def("eye.duration_seconds", "15");
        def("eye.damage_multiplier", "1.5");

        def("bad_time.radius", "8");
        def("bad_time.duration_seconds", "8");
        def("bad_time.damage_taken_multiplier", "1.5");
    }

    private SansConfig() {}

    private static void def(String key, String value) {
        DEFAULTS.put(key, value);
    }

    /** Multiplicador de partículas según particles.quality (se actualiza al cargar). */
    public static volatile double particleScale = 1.0;

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("sansmod.properties");
        try {
            boolean existed = Files.exists(file);
            if (existed) {
                try (Reader reader = Files.newBufferedReader(file)) {
                    PROPS.load(reader);
                }
            }

            // archivo de una versión anterior: los cooldowns y el hambre pasan a los nuevos valores
            boolean migrate = false;
            if (existed) {
                int fileVersion;
                try {
                    fileVersion = Integer.parseInt(PROPS.getProperty("config_version", "0").trim());
                } catch (NumberFormatException e) {
                    fileVersion = 0;
                }
                if (fileVersion < CONFIG_VERSION) {
                    for (Map.Entry<String, String> e : DEFAULTS.entrySet()) {
                        String k = e.getKey();
                        if (k.startsWith("cooldown.") || k.equals("exhaustion_per_cast") || k.equals("config_version")) {
                            PROPS.setProperty(k, e.getValue());
                        }
                    }
                    migrate = true;
                }
            }

            StringBuilder missing = new StringBuilder();
            for (Map.Entry<String, String> e : DEFAULTS.entrySet()) {
                if (!PROPS.containsKey(e.getKey())) {
                    missing.append(e.getKey()).append('=').append(e.getValue()).append('\n');
                    PROPS.setProperty(e.getKey(), e.getValue());
                }
            }
            if (!existed) {
                Files.createDirectories(file.getParent());
                Files.writeString(file, HEADER + "\n" + missing);
            } else if (migrate) {
                // se reescribe entero (conservando el resto de tus valores)
                StringBuilder all = new StringBuilder(HEADER).append('\n');
                for (String k : DEFAULTS.keySet()) {
                    all.append(k).append('=').append(PROPS.getProperty(k)).append('\n');
                }
                for (String k : PROPS.stringPropertyNames()) {
                    if (!DEFAULTS.containsKey(k)) all.append(k).append('=').append(PROPS.getProperty(k)).append('\n');
                }
                Files.writeString(file, all.toString());
                LOGGER.info("Sans Abilities: configuración actualizada a la versión {} (cooldowns nuevos)", CONFIG_VERSION);
            } else if (missing.length() > 0) {
                Files.writeString(file, "\n" + missing, StandardOpenOption.APPEND);
            }
            String q = PROPS.getProperty("particles.quality", "high").trim().toLowerCase();
            particleScale = q.equals("low") ? 0.35 : q.equals("medium") ? 0.65 : 1.0;
        } catch (IOException e) {
            LOGGER.warn("Sans Abilities: no se pudo leer/escribir la configuración", e);
        }
    }

    public static String s(String key) {
        return PROPS.getProperty(key, DEFAULTS.getOrDefault(key, "0"));
    }

    public static double d(String key) {
        try {
            return Double.parseDouble(s(key).trim());
        } catch (NumberFormatException e) {
            return Double.parseDouble(DEFAULTS.getOrDefault(key, "0"));
        }
    }

    public static int i(String key) {
        return (int) Math.round(d(key));
    }

    public static boolean b(String key) {
        return Boolean.parseBoolean(s(key).trim());
    }
}
