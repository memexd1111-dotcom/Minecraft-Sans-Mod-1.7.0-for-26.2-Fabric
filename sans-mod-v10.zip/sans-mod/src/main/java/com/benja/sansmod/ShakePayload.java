package com.benja.sansmod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Servidor -> cliente: sacudida de cámara (intensidad en grados y duración en ticks). */
public record ShakePayload(float intensity, int ticks) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShakePayload> TYPE =
            new CustomPacketPayload.Type<>(SansMod.id("shake"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ShakePayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.FLOAT, ShakePayload::intensity,
            ByteBufCodecs.VAR_INT, ShakePayload::ticks,
            ShakePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
