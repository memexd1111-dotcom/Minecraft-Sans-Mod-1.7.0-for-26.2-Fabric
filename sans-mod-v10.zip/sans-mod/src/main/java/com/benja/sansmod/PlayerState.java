package com.benja.sansmod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

/**
 * Estado de cada jugador en el servidor. Se guarda dentro de los datos del jugador de cada mundo
 * (esquive, karma, magia, cooldowns, habilidades inscritas, niveles y árbol de mejoras).
 */
public final class PlayerState {
    private static final Map<UUID, PlayerState> STATES = new HashMap<>();

    /** Lo que se guarda en disco. Los cooldowns se guardan como "ticks que faltan". */
    public record Saved(boolean dodgeOn, boolean karmaOn, int fatigue, List<Integer> cooldownLeft,
                        List<Integer> cooldownTotal, int serious, int badTime, int loadout,
                        List<Integer> xp, int points, List<Integer> nodes, int mana) {
        public static final Codec<Saved> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.BOOL.optionalFieldOf("dodge", true).forGetter(Saved::dodgeOn),
                Codec.BOOL.optionalFieldOf("karma", false).forGetter(Saved::karmaOn),
                Codec.INT.optionalFieldOf("fatigue", 0).forGetter(Saved::fatigue),
                Codec.INT.listOf().optionalFieldOf("cd_left", List.of()).forGetter(Saved::cooldownLeft),
                Codec.INT.listOf().optionalFieldOf("cd_total", List.of()).forGetter(Saved::cooldownTotal),
                Codec.INT.optionalFieldOf("serious", 0).forGetter(Saved::serious),
                Codec.INT.optionalFieldOf("bad_time", 0).forGetter(Saved::badTime),
                Codec.INT.optionalFieldOf("loadout", 0).forGetter(Saved::loadout),
                Codec.INT.listOf().optionalFieldOf("xp", List.of()).forGetter(Saved::xp),
                Codec.INT.optionalFieldOf("points", 0).forGetter(Saved::points),
                Codec.INT.listOf().optionalFieldOf("nodes", List.of()).forGetter(Saved::nodes),
                Codec.INT.optionalFieldOf("mana", -1).forGetter(Saved::mana)
        ).apply(i, Saved::new));
    }

    public static final AttachmentType<Saved> SAVED = AttachmentRegistry.create(
            SansMod.id("state"), builder -> builder.persistent(Saved.CODEC).copyOnDeath());

    public final long[] cooldownEnd = new long[Ability.ALL.length];
    public final int[] cooldownTotal = new int[Ability.ALL.length];
    public final int[] xp = new int[Ability.ALL.length];
    public final int[] nodes = new int[Progression.NODES.length];
    public int fatigue = 0;
    public long lastRecoverTick = 0;
    public long lastDodgeTick = -1000;
    public boolean dodgeOn = true;
    public boolean karmaOn = false;
    public long seriousUntil = 0;
    public long badTimeUntil = 0;
    /** Habilidades inscritas en el amuleto (un bit por habilidad no gratuita). */
    public int loadout = 0;
    public int points = 0;
    /** Magia actual; -1 = todavía sin inicializar (se llena al máximo). */
    public double mana = -1;
    /** Hasta qué tick se puede usar la Mesa de Sans después de abrirla. */
    public long tableUntil = 0;

    /** Fuerza el registro del adjunto al iniciar el mod (debe existir antes de cargar el mundo). */
    public static void init() {}

    public static PlayerState of(ServerPlayer player) {
        return STATES.computeIfAbsent(player.getUUID(), id -> load(player));
    }

    public boolean isUnlocked(Ability a) {
        return a.free || SansConfig.b("unlock_all") || (loadout & (1 << a.ordinal())) != 0;
    }

    public int slotsUsed() {
        return Integer.bitCount(loadout);
    }

    private static PlayerState load(ServerPlayer player) {
        PlayerState st = new PlayerState();
        Saved s = player.getAttached(SAVED);
        if (s == null) return st;

        long now = ((ServerLevel) player.level()).getServer().getTickCount();
        st.dodgeOn = s.dodgeOn();
        st.karmaOn = s.karmaOn();
        st.fatigue = Math.max(0, s.fatigue());
        st.lastRecoverTick = now;
        for (int i = 0; i < Ability.ALL.length; i++) {
            int left = i < s.cooldownLeft().size() ? s.cooldownLeft().get(i) : 0;
            int total = i < s.cooldownTotal().size() ? s.cooldownTotal().get(i) : 0;
            if (left > 0) {
                st.cooldownEnd[i] = now + left;
                st.cooldownTotal[i] = Math.max(left, total);
            }
            if (i < s.xp().size()) st.xp[i] = Math.max(0, s.xp().get(i));
        }
        for (int i = 0; i < st.nodes.length && i < s.nodes().size(); i++) {
            st.nodes[i] = Math.max(0, Math.min(Progression.NODES[i].max(), s.nodes().get(i)));
        }
        st.seriousUntil = s.serious() > 0 ? now + s.serious() : 0;
        st.badTimeUntil = s.badTime() > 0 ? now + s.badTime() : 0;
        st.loadout = s.loadout();
        st.points = Math.max(0, s.points());
        st.mana = s.mana();
        return st;
    }

    /** Guarda el estado en los datos del jugador (se escribe a disco con el resto del mundo). */
    public void save(ServerPlayer player, long now) {
        List<Integer> left = new ArrayList<>();
        List<Integer> total = new ArrayList<>();
        List<Integer> xpList = new ArrayList<>();
        for (int i = 0; i < Ability.ALL.length; i++) {
            left.add((int) Math.max(0, cooldownEnd[i] - now));
            total.add(cooldownTotal[i]);
            xpList.add(xp[i]);
        }
        List<Integer> nodeList = new ArrayList<>();
        for (int n : nodes) nodeList.add(n);
        player.setAttached(SAVED, new Saved(dodgeOn, karmaOn, fatigue, left, total,
                (int) Math.max(0, seriousUntil - now), (int) Math.max(0, badTimeUntil - now),
                loadout, xpList, points, nodeList, (int) Math.round(mana)));
    }

    public static void clear() {
        STATES.clear();
    }
}
