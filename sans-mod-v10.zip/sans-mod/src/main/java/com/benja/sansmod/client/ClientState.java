package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.SyncPayload;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Lo que el cliente sabe de sus habilidades (llega por SyncPayload). */
public final class ClientState {
    public static int selected = Ability.BONE.ordinal();
    public static final int[] remaining = new int[Ability.ALL.length];
    public static final int[] total = new int[Ability.ALL.length];
    /** Ticks de destello al terminar un cooldown (por habilidad). */
    public static final int[] flash = new int[Ability.ALL.length];
    public static int fatigue = 0;
    public static int maxFatigue = 8;
    public static boolean dodgeOn = true;
    public static boolean karmaOn = false;
    public static int serious = 0;
    public static int badTime = 0;
    /** Ticks que le quedan al agarre de telequinesis (0 = no sujetas a nadie). */
    public static int telekinesis = 0;
    /** Bits de las habilidades desbloqueadas (la mejora del amuleto). */
    public static int unlocked = -1;
    // magia, amuleto y progreso
    public static int mana = 100;
    public static int maxMana = 100;
    public static int slots = 3;
    public static int loadout = 0;
    public static int points = 0;
    public static int[] xp = new int[Ability.ALL.length];
    public static int[] nodes = new int[com.benja.sansmod.Progression.NODES.length];

    // ---- carga (mantener la tecla) ----
    public static int chargeIndex = -1;
    public static int chargeTicks = 0;

    // ---- sacudida de cámara ----
    public static boolean cameraShake = true;
    public static float shakeAmp = 0;
    public static int shakeTicks = 0;
    public static int shakeTotal = 1;

    private ClientState() {}

    public static boolean isUnlocked(int index) {
        return (unlocked & (1 << index)) != 0;
    }

    public static void shake(float amp, int ticks) {
        if (amp >= shakeAmp * shakeTicks / (float) Math.max(1, shakeTotal)) {
            shakeAmp = amp;
            shakeTicks = Math.max(1, ticks);
            shakeTotal = shakeTicks;
        }
    }

    public static void apply(SyncPayload p) {
        for (int i = 0; i < remaining.length && i < p.remaining().length; i++) {
            if (remaining[i] > 0 && p.remaining()[i] == 0) flash[i] = 12;
            remaining[i] = p.remaining()[i];
            total[i] = p.total()[i];
        }
        fatigue = p.fatigue();
        maxFatigue = Math.max(1, p.maxFatigue());
        dodgeOn = p.dodgeOn();
        karmaOn = p.karmaOn();
        serious = p.serious();
        badTime = p.badTime();
        telekinesis = p.telekinesis();
        unlocked = p.unlocked();
        mana = p.mana();
        maxMana = Math.max(1, p.maxMana());
        slots = p.slots();
        loadout = p.loadout();
        points = p.points();
        if (p.xp().length == xp.length) xp = p.xp();
        if (p.nodes().length == nodes.length) nodes = p.nodes();
    }

    /** Cada tick del cliente: los contadores bajan solos entre sincronizaciones. */
    public static void tick() {
        for (int i = 0; i < remaining.length; i++) {
            if (remaining[i] > 0) {
                remaining[i]--;
                if (remaining[i] == 0) flash[i] = 12; // ¡lista!
            }
            if (flash[i] > 0) flash[i]--;
        }
        if (serious > 0) serious--;
        if (badTime > 0) badTime--;
        if (telekinesis > 0) telekinesis--;
    }

    public static void cycle(int delta) {
        int n = Ability.ALL.length;
        selected = Math.floorMod(selected + delta, n);
        saveSelected();
    }

    // ---------- persistencia (config/sansmod-client.properties) ----------

    private static Path selectedFile() {
        return FabricLoader.getInstance().getConfigDir().resolve("sansmod-client.properties");
    }

    public static void loadSelected() {
        try {
            Path file = selectedFile();
            if (!Files.exists(file)) return;
            Properties props = new Properties();
            try (Reader reader = Files.newBufferedReader(file)) {
                props.load(reader);
            }
            int value = Integer.parseInt(props.getProperty("selected", String.valueOf(selected)).trim());
            if (value >= 0 && value < Ability.ALL.length) selected = value;
            cameraShake = Boolean.parseBoolean(props.getProperty("camera_shake", "true").trim());
        } catch (IOException | NumberFormatException e) {
            // si el archivo está dañado se ignora y se usan los valores por defecto
        }
    }

    public static void saveSelected() {
        try {
            Properties props = new Properties();
            props.setProperty("selected", String.valueOf(selected));
            props.setProperty("camera_shake", String.valueOf(cameraShake)); // pon false para quitar la sacudida
            try (Writer writer = Files.newBufferedWriter(selectedFile())) {
                props.store(writer, "Sans Abilities - ajustes del cliente");
            }
        } catch (IOException e) {
            // no es crítico
        }
    }
}
