package com.benja.sansmod.client;

import com.benja.sansmod.Ability;
import com.benja.sansmod.AbilityItems;
import com.benja.sansmod.TableActionPayload;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Mesa de Sans: inscribe en el amuleto las habilidades de los objetos que llevas, o quítalas para ponerlas de nuevo. */
public class TableScreen extends Screen {
    private static final int ROW = 20;
    private final List<Ability> rows = new ArrayList<>();
    private final List<Button> buttons = new ArrayList<>();
    private int left;
    private int top;

    public TableScreen() {
        super(Component.translatable("screen.sansmod.table"));
        for (Ability a : Ability.ALL) {
            if (!a.free) rows.add(a);
        }
    }

    private static int countOf(Ability a) {
        var player = Minecraft.getInstance().player;
        if (player == null) return 0;
        var item = AbilityItems.itemFor(a);
        int n = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    private static boolean inscribed(Ability a) {
        return (ClientState.loadout & (1 << a.ordinal())) != 0;
    }

    @Override
    protected void init() {
        left = this.width / 2 - 150;
        top = Math.max(40, this.height / 2 - rows.size() * ROW / 2 - 6);
        buttons.clear();
        for (int i = 0; i < rows.size(); i++) {
            final Ability a = rows.get(i);
            Button b = Button.builder(Component.empty(), btn -> {
                // quitar si ya está inscrita; si no, inscribirla (el servidor lo valida)
                ClientPlayNetworking.send(new TableActionPayload(!inscribed(a), a.ordinal()));
            }).bounds(left + 214, top + i * ROW, 86, ROW - 2).build();
            buttons.add(b);
            addRenderableWidget(b);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        for (int i = 0; i < rows.size(); i++) {
            Ability a = rows.get(i);
            boolean in = inscribed(a);
            int have = countOf(a);
            buttons.get(i).setMessage(Component.translatable(in ? "screen.sansmod.remove" : "screen.sansmod.inscribe"));
        }
        super.extractRenderState(g, mouseX, mouseY, partialTick);

        g.text(this.font, this.title, (this.width - this.font.width(this.title)) / 2, 12, 0xFFFFFFFF, true);
        Component slotsLine = Component.translatable("screen.sansmod.slots",
                Integer.bitCount(ClientState.loadout), ClientState.slots);
        g.text(this.font, slotsLine, (this.width - this.font.width(slotsLine)) / 2, 25, 0xFFFFEE88, true);

        for (int i = 0; i < rows.size(); i++) {
            Ability a = rows.get(i);
            int y = top + i * ROW;
            AbilityHud.icon(g, a.ordinal(), left, y - 1, 18);
            g.text(this.font, Component.translatable("ability.sansmod." + a.id), left + 24, y + 1, 0xFFFFFFFF, true);
            boolean in = inscribed(a);
            int have = countOf(a);
            Component item = new ItemStack(AbilityItems.itemFor(a)).getHoverName();
            Component status = in ? Component.translatable("screen.sansmod.in_amulet")
                    : have > 0 ? Component.translatable("screen.sansmod.have", have)
                    : Component.translatable("screen.sansmod.missing", item);
            g.text(this.font, status, left + 24, y + 10, in ? 0xFF77FF77 : have > 0 ? 0xFFFFEE88 : 0xFF999999, false);
        }
        Component hint = Component.translatable("screen.sansmod.table_hint");
        g.text(this.font, hint, (this.width - this.font.width(hint)) / 2, this.height - 16, 0xFF888888, false);
    }
}
