# Sans Abilities (Fabric, Minecraft 26.2, cliente + servidor)

Un amuleto que da habilidades inspiradas en Sans. Necesita estar instalado en el cliente **y** en el servidor
(en un mundo de un jugador ya cumple las dos cosas). Requiere Fabric API.

## Compilar el .jar
- **Con `zip_a_jar.bat` (Windows):** arrastra este .zip encima del .bat. La primera vez descarga JDK 25 y
  Gradle 9.5.1; después compila y deja `sans-mod-1.6.0.jar` junto al .zip. Copia ese .jar a la carpeta `mods`
  y **borra el .jar de versiones anteriores** (Fabric no admite dos copias del mismo mod).
- **Con GitHub:** sube el contenido de la carpeta `sans-mod` a la raíz del repositorio; el workflow
  `.github/workflows/build.yml` deja el .jar como artefacto `sans-mod-jar`.
- Necesitas Minecraft 26.2 con Fabric Loader 0.19.3 o superior y Fabric API.

## Conseguir el amuleto
- Comando: `/give @s sansmod:sans_charm` (y `/give @s sansmod:hot_dog`).
- Creativo: pestaña Combate (amuleto) y Comida (perrito caliente).
- Supervivencia (balance): receta cara en `data/sansmod/recipe/sans_charm.json`:
  4 bloques de diamante, 2 estrellas del Nether, 2 bloques de hueso y 1 calavera de esqueleto.
  Si lo quieres solo por comando, borra ese archivo del proyecto antes de compilar.
  El perrito caliente se craftea con 1 chuleta cocinada + 1 pan (da 2).

## Controles (se cambian en Opciones > Controles)
- **Una tecla por habilidad** (aparecen en Controles > Sans Abilities, y las puedes cambiar):
  **O** esquive (activar/desactivar), **K** karma (activar/desactivar), **B** huesos, **N** muro de huesos,
  **G** blaster, **H** lluvia de blasters, **Y** telequinesis (agarrar; otra vez = lanzar), **J** atajo,
  **U** ojo brillante, **I** mal momento. No cambian la habilidad elegida en el menú.
- **R**: lanzar la habilidad elegida
- **V**: menú para elegir habilidad (clic en el icono)
- **X / Z**: siguiente / anterior habilidad
El amuleto debe estar en cualquier lugar del inventario.

## Habilidades
Esquive (automático, con energía), Karma, Huesos, Muro de huesos, Blaster, Lluvia de blasters,
Telequinesis (agarras al objetivo y lo mueves con la mirada; si lo estrellas contra suelo/pared recibe daño;
segundo uso = lanzarlo), Atajo (teletransporte, se detiene ante paredes y suelo), Ojo brillante, Mal momento. Los perritos calientes curan.

## Configuración
`config/sansmod.properties` (se crea sola): cooldowns, daños, rangos, energía de esquive, costo de hambre, etc.
Al actualizar de una versión anterior, los cooldowns y el costo de hambre se ajustan solos a los nuevos valores
(el resto de tus cambios se conserva).

Cooldowns por defecto (segundos): huesos 1.5, muro de huesos 6, blaster 8, lluvia de blasters 20,
telequinesis 6 (cuenta desde que sueltas al objetivo), atajo 3, ojo brillante 30, mal momento 35.

## Novedades de esta versión
- **Persistencia:** esquive, karma, energía de esquive, cooldowns y estados activos (ojo, mal momento) se guardan
  en los datos del jugador de cada mundo y se recuperan al volver a entrar. La habilidad elegida en el menú se
  recuerda en `config/sansmod-client.properties`.
- **Recarga a la vista:** cada icono muestra los segundos que faltan (enteros desde 10 s, con un decimal después).
- **Esquive:** deja un eco celeste translúcido donde estabas y un aura mientras dura la ventana de esquive.
- **Blaster:** esfera de energía que crece al cargar, destello en la boca, rayo en capas que se va afinando,
  y explosión con onda expansiva al impactar.

## Novedades de la versión 1.5.0
- **Carga:** mantén la tecla de **huesos**, **blaster** (y los huesos azul/naranja) para cargar: más huesos o un rayo
  más grueso y dañino. Hay una barra bajo la mira y un tono que sube. Un toque rápido lanza sin carga.
- **Karma = KR:** cada golpe suma una carga de daño que ignora la invulnerabilidad corta; aura morada alrededor.
- **Telequinesis:** agachado acerca al objetivo y corriendo lo aleja; anillo luminoso sobre el objetivo; el HUD
  muestra los segundos que quedan sujetándolo.
- **Lluvia de blasters:** círculos de aviso en el suelo, cada calavera apunta a un punto distinto y cae un pilar final.
- **Calavera de blaster:** se inclina hacia donde miras y abre la mandíbula al cargar.
- **Atajo:** rastro cian entre la salida y la llegada y eco donde estabas.
- **Sacudida de cámara** con blaster, lluvia, muro y choques de telequinesis (se quita con `camera_shake=false` en
  `config/sansmod-client.properties`).
- **Interfaz:** tecla sobre cada icono, destello cuando la habilidad está lista, menú radial con datos reales
  (daño, alcance, recarga) y habilidades bloqueadas atenuadas.
- **(Reemplazado en 1.6.0)** la plantilla y la mesa de herrería ya no se usan; ver más abajo.

## Novedades de la versión 1.6.0
- **Habilidades como objetos y Mesa de Sans:** el amuleto trae gratis Esquive, Huesos y Atajo. Las demás se
  desbloquean con un objeto que se **inscribe en el amuleto** en la **Mesa de Sans** (clic derecho). Puedes quitar
  una habilidad (recuperas su objeto) para poner otra: el amuleto tiene ranuras limitadas (`amulet.slots`, +1 por
  rango del árbol).
  - Hueso azul y Hueso naranja: esqueletos (esqueleto, vagabundo y pantanoso).
  - Esencia de Karma (Karma) y Costilla ancestral (Muro de huesos): Esqueleto Kármico (Nether).
  - Reloj roto (Mal momento) y Ojo ardiente (Ojo brillante): Espectro del Reloj (Nether).
  - Perla telequinética (Telequinesis): Enderman Telequinético (End).
  - Fragmento de Gaster (Blaster) y Corona de Gaster (Lluvia de blasters): Vigía de Gaster (End).
  - Receta de la Mesa de Sans: `BBB / LDL / SSS` con B = bloque de hueso, L = lapislázuli, D = diamante, S = ladrillos de piedra.
- **Mobs nuevos:** son variantes de mobs vanilla (con nombre, aura y ataques propios), no entidades con modelo nuevo.
  Aparecen con `mobs.variant_chance`. Además algunos esqueletos normales atacan con huesos azules y naranjas
  (`mobs.sans_skeleton_chance`): quédate quieto contra los naranjas y muévete contra los azules.
- **Niveles de habilidad:** cada habilidad sube de nivel con el uso (`levels.xp`), con más daño y menos recarga, y
  cada nivel da 1 punto para el **árbol de mejoras** (tecla `.` o botón en el menú radial).
- **Magia (MP):** `resource_mode=mana` (por defecto) hace que las habilidades cuesten magia (`mana.cost.*`) en vez
  de hambre; con `resource_mode=hunger` vuelve el costo de hambre. Barra morada en el HUD.
- **Protecciones:** no se daña a mascotas domadas, aldeanos/comerciantes ni a quien esté en tu equipo
  (`protect.pets`, `protect.villagers`, `protect.teams`).
- **Calidad de partículas:** `particles.quality=high|medium|low` en la config del servidor.
- Para probar sin conseguir objetos: `unlock_all=true` en la config.

## Simplificaciones
- Los huesos, calaveras y el muro son armor stands invisibles con un objeto en la cabeza. Ahora ese objeto
  tiene modelo 3D propio (`assets/sansmod/models/item/blaster_skull.json`, `bone_projectile.json`,
  `bone_wall.json`, hechos con cajas y un atlas de textura). Los rayos son partículas. No hay renderers propios.
- Sonidos y partículas de vanilla. Los iconos (32x32) y las texturas se generaron por código (reemplázalas en
  `assets/sansmod/textures` por las tuyas).
- El estado (cooldowns, energía) se pierde al cerrar el mundo.
